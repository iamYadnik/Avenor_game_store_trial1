package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.luaj.vm2.*
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.TwoArgFunction
import org.luaj.vm2.lib.ZeroArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.File

/**
 * LuaRuntimeManager is responsible for executing Lua scripts within the
 * app. It wraps the LuaJ interpreter and exposes a limited set of
 * functions (print, save_state, load_state, get_profile_id) to the
 * script environment. Script output is delivered to observers via a
 * StateFlow of log messages.
 *
 * Each instance of this class is tied to a single game ID, which is
 * used when saving and loading state via [SaveManager].
 */
class LuaRuntimeManager(
    private val context: Context,
    private val gameId: Int
) {
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    /**
     * Represents a drawing operation queued by a Lua script. Currently
     * supports drawing rectangles and text. Additional primitives can
     * be added in the future by extending this sealed class.
     */
    sealed class DrawOperation {
        data class Rect(val x: Float, val y: Float, val width: Float, val height: Float, val color: Int) : DrawOperation()
        data class Text(val x: Float, val y: Float, val text: String, val size: Float, val color: Int) : DrawOperation()
    }

    // Pending operations collected between calls to draw_api.render(). They are
    // committed to [_drawOps] when render() is invoked from Lua.
    private val pendingOps = mutableListOf<DrawOperation>()
    private val _drawOps = MutableStateFlow<List<DrawOperation>>(emptyList())
    val drawOps: StateFlow<List<DrawOperation>> = _drawOps

    /**
     * Executes a Lua script located at the given file path. The
     * execution occurs on a background thread. Any output produced by
     * calls to `print` within the script will be captured and appended
     * to the logs.
     *
     * @param scriptPath Absolute path of the Lua script file to run.
     */
    fun runScript(scriptPath: String) {
        // Launch the interpreter on an IO thread so the UI stays responsive
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Set up a new environment with the standard library
                val globals: Globals = JsePlatform.standardGlobals()

                // Override the print function so that Lua print calls
                // append to our logs instead of stdout
                globals.set("print", object : VarArgFunction() {
                    override fun invoke(args: Varargs?): Varargs {
                        val builder = StringBuilder()
                        val n = args?.narg() ?: 0
                        for (i in 1..n) {
                            val v = args?.arg(i)
                            if (i > 1) builder.append("\t")
                            builder.append(v?.tojstring())
                        }
                        appendLog(builder.toString())
                        return LuaValue.NIL
                    }
                })

                // Expose save_state(key, value) to Lua
                globals.set("save_state", object : TwoArgFunction() {
                    override fun call(key: LuaValue, value: LuaValue): LuaValue {
                        val profileId = UserManager.getProfileId(context)
                        // Save JSON object storing key->value pair
                        val data = value.tojstring()
                        SaveManager.saveGameState(context, profileId, gameId, data)
                        return LuaValue.NIL
                    }
                })

                // Expose load_state(key) -> value to Lua
                globals.set("load_state", object : OneArgFunction() {
                    override fun call(key: LuaValue): LuaValue {
                        val profileId = UserManager.getProfileId(context)
                        val data = SaveManager.loadGameState(context, profileId, gameId)
                        return if (data != null) LuaValue.valueOf(data) else LuaValue.NIL
                    }
                })

                // Expose get_profile_id() -> string
                globals.set("get_profile_id", object : ZeroArgFunction() {
                    override fun call(): LuaValue {
                        return LuaValue.valueOf(UserManager.getProfileId(context))
                    }
                })

                // Expose get_gamepad_state() -> table
                globals.set("get_gamepad_state", object : ZeroArgFunction() {
                    override fun call(): LuaValue {
                        return getGamepadStateLua()
                    }
                })

                // Expose load_asset(filename) -> string or nil
                globals.set("load_asset", object : OneArgFunction() {
                    override fun call(filename: LuaValue): LuaValue {
                        val name = filename.tojstring()
                        val content = loadAssetFile(name)
                        return if (content != null) LuaValue.valueOf(content) else LuaValue.NIL
                    }
                })

                // Set up a draw_api table exposing simple 2D drawing functions.
                val drawApi = LuaTable()
                // draw_rect(x, y, width, height, color)
                drawApi.set("draw_rect", object : VarArgFunction() {
                    override fun invoke(args: Varargs?): Varargs {
                        try {
                            // Extract parameters and convert to floats/ints
                            val x = args?.arg(1)?.tofloat() ?: 0f
                            val y = args?.arg(2)?.tofloat() ?: 0f
                            val w = args?.arg(3)?.tofloat() ?: 0f
                            val h = args?.arg(4)?.tofloat() ?: 0f
                            val colorStr = args?.arg(5)?.tojstring() ?: "#FFFFFFFF"
                            val colorInt = parseColor(colorStr)
                            pendingOps.add(DrawOperation.Rect(x, y, w, h, colorInt))
                        } catch (e: Exception) {
                            appendLog("[draw_api] draw_rect error: ${'$'}{e.message}")
                        }
                        return LuaValue.NIL
                    }
                })
                // draw_text(x, y, string, size, color)
                drawApi.set("draw_text", object : VarArgFunction() {
                    override fun invoke(args: Varargs?): Varargs {
                        try {
                            val x = args?.arg(1)?.tofloat() ?: 0f
                            val y = args?.arg(2)?.tofloat() ?: 0f
                            val text = args?.arg(3)?.tojstring() ?: ""
                            val size = args?.arg(4)?.tofloat() ?: 12f
                            val colorStr = args?.arg(5)?.tojstring() ?: "#FFFFFFFF"
                            val colorInt = parseColor(colorStr)
                            pendingOps.add(DrawOperation.Text(x, y, text, size, colorInt))
                        } catch (e: Exception) {
                            appendLog("[draw_api] draw_text error: ${'$'}{e.message}")
                        }
                        return LuaValue.NIL
                    }
                })
                // clear_screen()
                drawApi.set("clear_screen", object : ZeroArgFunction() {
                    override fun call(): LuaValue {
                        pendingOps.clear()
                        // Clear committed operations as well
                        _drawOps.value = emptyList()
                        return LuaValue.NIL
                    }
                })
                // render() commits all pending operations to the UI
                drawApi.set("render", object : ZeroArgFunction() {
                    override fun call(): LuaValue {
                        // Publish a copy of pending operations and clear the pending list
                        _drawOps.value = pendingOps.toList()
                        pendingOps.clear()
                        return LuaValue.NIL
                    }
                })
                // Register draw_api global
                globals.set("draw_api", drawApi)

                // Load and execute the script file
                val file = File(scriptPath)
                if (file.exists()) {
                    val chunk = globals.loadfile(file.absolutePath)
                    chunk.call()
                } else {
                    appendLog("Script file not found: $scriptPath")
                }
            } catch (e: Exception) {
                appendLog("Lua error: ${e.message}")
            }
        }
    }

    /**
     * Clears the current log. Use this when the user presses "Clear Output".
     */
    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun appendLog(message: String) {
        // Append message to current logs atomically
        _logs.value = _logs.value + message
    }

    /**
     * Builds a Lua table representing the current state of the first
     * connected gamepad.  If no gamepad is detected, a table of all
     * false values is returned and a warning is logged.  Keys include
     * up, down, left, right, a, b, x, y, start and select.
     */
    private fun getGamepadStateLua(): LuaValue {
        val table = LuaTable()
        val keys = listOf(
            "up", "down", "left", "right",
            "a", "b", "x", "y",
            "start", "select"
        )
        // Default all values to false
        keys.forEach { key -> table.set(key, LuaValue.FALSE) }
        try {
            val inputManager = context.getSystemService(Context.INPUT_SERVICE) as android.hardware.input.InputManager
            val deviceIds = inputManager.inputDeviceIds
            val devices = deviceIds.mapNotNull { id -> android.view.InputDevice.getDevice(id) }
                .filter { device -> (device.sources and android.view.InputDevice.SOURCE_GAMEPAD) == android.view.InputDevice.SOURCE_GAMEPAD ||
                                    (device.sources and android.view.InputDevice.SOURCE_JOYSTICK) == android.view.InputDevice.SOURCE_JOYSTICK }
            if (devices.isEmpty()) {
                appendLog("[LuaRuntime] No gamepad detected; get_gamepad_state returns all false")
                return table
            }
            val device = devices.first()
            // Helper to test if any connected device has the specified key pressed
            fun isPressed(code: Int): Boolean {
                return devices.any { d -> d.isKeyPressed(code) }
            }
            val up = isPressed(android.view.KeyEvent.KEYCODE_DPAD_UP)
            val down = isPressed(android.view.KeyEvent.KEYCODE_DPAD_DOWN)
            val left = isPressed(android.view.KeyEvent.KEYCODE_DPAD_LEFT)
            val right = isPressed(android.view.KeyEvent.KEYCODE_DPAD_RIGHT)
            val a = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_A)
            val b = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_B)
            val x = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_X)
            val y = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_Y)
            val start = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_START)
            val select = isPressed(android.view.KeyEvent.KEYCODE_BUTTON_SELECT)
            // Populate the table with boolean values
            table.set("up", if (up) LuaValue.TRUE else LuaValue.FALSE)
            table.set("down", if (down) LuaValue.TRUE else LuaValue.FALSE)
            table.set("left", if (left) LuaValue.TRUE else LuaValue.FALSE)
            table.set("right", if (right) LuaValue.TRUE else LuaValue.FALSE)
            table.set("a", if (a) LuaValue.TRUE else LuaValue.FALSE)
            table.set("b", if (b) LuaValue.TRUE else LuaValue.FALSE)
            table.set("x", if (x) LuaValue.TRUE else LuaValue.FALSE)
            table.set("y", if (y) LuaValue.TRUE else LuaValue.FALSE)
            table.set("start", if (start) LuaValue.TRUE else LuaValue.FALSE)
            table.set("select", if (select) LuaValue.TRUE else LuaValue.FALSE)
        } catch (e: Exception) {
            appendLog("[LuaRuntime] Error polling gamepad state: ${e.message}")
        }
        return table
    }

    /**
     * Loads a file from the installed game's directory and returns its
     * contents as a Base64 string.  If the file is not found or cannot
     * be read, null is returned and a log message is emitted.
     */
    private fun loadAssetFile(name: String): String? {
        return try {
            val dir = File(context.filesDir, "games/$gameId")
            val file = File(dir, name)
            if (!file.exists()) {
                appendLog("[LuaRuntime] load_asset: file not found: $name")
                null
            } else {
                val bytes = file.readBytes()
                // Encode bytes as Base64 to allow safe transfer to Lua
                val encoded = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                encoded
            }
        } catch (e: Exception) {
            appendLog("[LuaRuntime] load_asset error: ${e.message}")
            null
        }
    }

    /**
     * Parses a CSS-like hex color string into an ARGB integer. Accepts
     * strings of the form "#RRGGBB" or "#AARRGGBB". If parsing fails,
     * white (0xFFFFFFFF) is returned.
     */
    private fun parseColor(str: String): Int {
        return try {
            // Remove leading '#' if present
            val clean = str.trim().removePrefix("#")
            when (clean.length) {
                6 -> {
                    // If no alpha provided, assume fully opaque
                    val rgb = clean.toLong(16)
                    (0xFF000000 or rgb).toInt()
                }
                8 -> {
                    // Has alpha at the beginning
                    clean.toLong(16).toInt()
                }
                else -> 0xFFFFFFFF.toInt()
            }
        } catch (e: Exception) {
            0xFFFFFFFF.toInt()
        }
    }
}