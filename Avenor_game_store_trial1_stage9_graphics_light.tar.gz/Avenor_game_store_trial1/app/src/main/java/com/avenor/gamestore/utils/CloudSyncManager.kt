package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Base64
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.security.SecureRandom

/**
 * Simulated cloud sync manager.  In a real implementation these methods
 * would interact with a remote server (for example a REST API, Firebase
 * Storage or a Git repository) to upload/download save data.  This MVP
 * approximates that behaviour by creating a ZIP archive of the saves
 * directory and storing it under `files/cloud_saves/{profileId}.zip`.
 * Restoring a save unpacks the archive back into the local saves
 * directory.  All operations are performed on a background thread via
 * Kotlin coroutines.
 */
object CloudSyncManager {

    /**
     * Returns a File reference to the directory where cloud archives are
     * stored locally.  The directory is created if necessary.
     */
    private fun getCloudDir(context: Context): File {
        val dir = File(context.filesDir, "cloud_saves")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Compress the save directory for the given profile into a ZIP file
     * under the cloud directory.  Existing archives will be replaced.
     *
     * @param context Application context used to resolve file paths.
     * @param profileId The user profile whose saves are being backed up.
     */
    suspend fun backupSaves(context: Context, profileId: String) {
        withContext(Dispatchers.IO) {
            val saveDir = File(context.filesDir, "saves/$profileId")
            val cloudDir = getCloudDir(context)
            if (!saveDir.exists()) {
                // Nothing to back up
                return@withContext
            }
            val zipFile = File(cloudDir, "$profileId.zip")
            // First write the plain ZIP to a temporary buffer
            val tempFile = File.createTempFile("cloud_temp", ".zip", context.cacheDir)
            ZipOutputStream(FileOutputStream(tempFile)).use { zos ->
                saveDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entryName = file.relativeTo(saveDir).path
                    val entry = ZipEntry(entryName)
                    zos.putNextEntry(entry)
                    file.inputStream().use { input ->
                        input.copyTo(zos)
                    }
                    zos.closeEntry()
                }
            }
            // Encrypt the zip file with the profile key
            val key = getSecretKey(context, profileId)
            val zipBytes = tempFile.readBytes()
            val encrypted = encryptBytes(zipBytes, key)
            FileOutputStream(zipFile).use { fos ->
                fos.write(encrypted)
            }
            tempFile.delete()
        }
    }

    /**
     * Restore save data for the given profile from the local cloud archive.
     * If no archive exists this function silently does nothing.  Existing
     * save data will be replaced by the contents of the archive.
     *
     * @param context Application context used to resolve file paths.
     * @param profileId The user profile whose saves are being restored.
     */
    suspend fun restoreSaves(context: Context, profileId: String) {
        withContext(Dispatchers.IO) {
            val cloudDir = getCloudDir(context)
            val zipFile = File(cloudDir, "$profileId.zip")
            if (!zipFile.exists()) {
                // Nothing to restore
                return@withContext
            }
            // Destination directory
            val saveDir = File(context.filesDir, "saves/$profileId")
            // Remove existing saves
            if (saveDir.exists()) {
                saveDir.deleteRecursively()
            }
            saveDir.mkdirs()
            // Decrypt the zip file contents
            val key = getSecretKey(context, profileId)
            val encryptedBytes = FileInputStream(zipFile).use { it.readBytes() }
            val decryptedBytes = decryptBytes(encryptedBytes, key) ?: return@withContext
            // Unzip from decrypted byte array
            ZipInputStream(decryptedBytes.inputStream()).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val filePath = File(saveDir, entry.name)
                    if (entry.isDirectory) {
                        filePath.mkdirs()
                    } else {
                        filePath.parentFile?.mkdirs()
                        FileOutputStream(filePath).use { fos ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            var length: Int
                            while (zis.read(buffer).also { length = it } > 0) {
                                fos.write(buffer, 0, length)
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
    }

    /**
     * Retrieve the AES key for the specified profile.  This replicates the
     * logic in [SaveManager] to avoid exposing the key retrieval outside of
     * that class.  Keys are stored in SharedPreferences under
     * `profile_keys/key_{profileId}` and generated if missing.
     */
    private fun getSecretKey(context: Context, profileId: String): SecretKeySpec {
        val prefs = context.getSharedPreferences("profile_keys", Context.MODE_PRIVATE)
        val keyName = "key_" + profileId
        var keyString = prefs.getString(keyName, null)
        if (keyString.isNullOrEmpty()) {
            val keyBytes = ByteArray(32)
            SecureRandom().nextBytes(keyBytes)
            keyString = Base64.encodeToString(keyBytes, Base64.NO_WRAP)
            prefs.edit().putString(keyName, keyString).apply()
        }
        val decoded = Base64.decode(keyString, Base64.NO_WRAP)
        return SecretKeySpec(decoded, "AES")
    }

    /**
     * Encrypt arbitrary bytes using AES/CBC/PKCS5Padding.  A random IV is
     * generated and prepended to the ciphertext.  The caller is responsible
     * for storing and later splitting the IV when decrypting.
     */
    private fun encryptBytes(data: ByteArray, key: SecretKeySpec): ByteArray {
        val ivBytes = ByteArray(16)
        SecureRandom().nextBytes(ivBytes)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(ivBytes))
        val encrypted = cipher.doFinal(data)
        return ivBytes + encrypted
    }

    /**
     * Decrypt bytes produced by [encryptBytes].  If decryption fails the
     * function returns null.
     */
    private fun decryptBytes(data: ByteArray, key: SecretKeySpec): ByteArray? {
        if (data.size < 17) return null
        return try {
            val iv = data.copyOfRange(0, 16)
            val enc = data.copyOfRange(16, data.size)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
            cipher.doFinal(enc)
        } catch (_: Exception) {
            null
        }
    }
}