package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import com.avenor.gamestore.models.Game

/**
 * Utility class responsible for installing and checking game assets.
 *
 * Each game ships with a ZIP archive stored in the application's assets folder
 * (under `game_assets/`). This manager extracts the archive into the app's
 * internal storage to make it accessible offline. Only basic ZIP archives are
 * supported (no encryption).
 */
object GameAssetManager {
    private const val GAMES_DIR = "games"

    /**
     * Determine if the given game has already been installed on disk.
     *
     * @return true if a directory exists for the game, false otherwise.
     */
    fun isGameInstalled(context: Context, game: Game): Boolean {
        val dir = File(context.filesDir, "$GAMES_DIR/${game.id}")
        return dir.exists() && dir.isDirectory
    }

    /**
     * Install (extract) the ZIP archive for the given game into internal storage.
     * This function runs on the IO dispatcher to avoid blocking the main thread.
     */
    suspend fun installGame(context: Context, game: Game) {
        withContext(Dispatchers.IO) {
            // Destination directory
            val destDir = File(context.filesDir, "$GAMES_DIR/${game.id}")
            if (!destDir.exists()) {
                destDir.mkdirs()
            }
            // Open the zip archive from assets
            val assetPath = game.gameAssetZipUrl
            val inputStream: InputStream = context.assets.open(assetPath)
            ZipInputStream(inputStream).use { zipIn ->
                var entry: ZipEntry? = zipIn.nextEntry
                while (entry != null) {
                    val filePath = File(destDir, entry.name)
                    if (entry.isDirectory) {
                        filePath.mkdirs()
                    } else {
                        // Ensure parent directories
                        filePath.parentFile?.mkdirs()
                        FileOutputStream(filePath).use { fos ->
                            val buffer = ByteArray(4096)
                            var len: Int
                            while (zipIn.read(buffer).also { len = it } > 0) {
                                fos.write(buffer, 0, len)
                            }
                        }
                    }
                    zipIn.closeEntry()
                    entry = zipIn.nextEntry
                }
            }
        }
    }
}