package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avenor.gamestore.models.Game
import com.avenor.gamestore.data.GameRepository
import com.avenor.gamestore.utils.GameAssetManager
import com.avenor.gamestore.utils.SaveManager
import com.avenor.gamestore.utils.UserManager
import com.avenor.gamestore.utils.CloudSyncManager
import android.widget.Toast

/**
 * Game detail page displays information about a single game.
 *
 * @param gameId ID of the game to show.
 * @param onBack Callback when user presses the back button.
 * @param onAddToCart Callback when user taps Add to Cart.
 * @param onInstall Callback when user taps Install (dummy).
 */
@Composable
fun GameDetailScreen(
    gameId: Int,
    onBack: () -> Unit,
    /**
     * Called when the user opts to play the game or try a demo. The caller should
     * navigate to the gameplay screen with the provided gameId.
     */
    onPlayGame: (Int) -> Unit,
    /**
     * Called when the user wants to open the install/download manager. Currently unused.
     */
    onShowDownloads: () -> Unit
) {
    val context = LocalContext.current
    val game = remember(gameId) {
        GameRepository.loadGames(context).find { it.id == gameId }
    }
    // UI state for installation
    val isInstallingState = remember { mutableStateOf(false) }
    val isInstalledState = remember { mutableStateOf(false) }
    // Whether a save file exists for this game/profile
    val hasSaveState = remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Check installation status when the game loads
    LaunchedEffect(game) {
        game?.let {
            isInstalledState.value = GameAssetManager.isGameInstalled(context, it)
            // Determine if a save file exists under the current profile
            val profileId = UserManager.getProfileId(context)
            hasSaveState.value = SaveManager.hasSave(context, profileId, it.id)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(text = game?.title ?: "Game", fontWeight = FontWeight.Bold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            // Secondary actions show the downloads manager placeholder
            actions = {
                IconButton(onClick = onShowDownloads) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = "Downloads"
                    )
                }
            },
            colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )
        if (game != null) {
            val imageId = remember(game.thumbnail) {
                context.resources.getIdentifier(game.thumbnail, "drawable", context.packageName)
            }
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier
                    .verticalScroll(scrollState)
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                // Cover image
                if (imageId != 0) {
                    Image(
                        painter = painterResource(id = imageId),
                        contentDescription = game.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = game.title,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                // Developer and genre information
                Text(
                    text = "Developer: ${game.developer}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "Genre: ${game.genre}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = game.fullDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(24.dp))
                // Buttons row
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Try demo button (always available)
                    Button(onClick = { onPlayGame(game.id) }) {
                        Text(text = "Try Demo")
                    }
                    if (isInstallingState.value) {
                        // Show installing state
                        Button(onClick = {}, enabled = false) {
                            Text(text = "Installing…")
                        }
                    } else {
                        if (isInstalledState.value) {
                            val buttonLabel = if (hasSaveState.value) "Resume Game" else "Play Now"
                            Button(onClick = { onPlayGame(game.id) }) {
                                Text(text = buttonLabel)
                            }
                        } else {
                            Button(onClick = {
                                // Launch installation
                                isInstallingState.value = true
                                scope.launch {
                                    GameAssetManager.installGame(context, game)
                                    isInstallingState.value = false
                                    isInstalledState.value = true
                                }
                            }) {
                                Text(text = "Install")
                            }
                        }
                    }
                }
                // Clear save button appears only if a save exists
                if (isInstalledState.value && hasSaveState.value) {
                    Spacer(modifier = Modifier.height(8.dp))
                    // Clear save
                    Button(onClick = {
                        val profileId = UserManager.getProfileId(context)
                        SaveManager.clearGameState(context, profileId, game.id)
                        hasSaveState.value = false
                        Toast.makeText(context, "Save data cleared", Toast.LENGTH_SHORT).show()
                    }) {
                        Text(text = "Clear Save")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    // Sync save to "cloud"
                    Button(onClick = {
                        val profileId = UserManager.getProfileId(context)
                        scope.launch {
                            CloudSyncManager.backupSaves(context, profileId)
                            Toast.makeText(context, "Save synced to cloud", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text(text = "Sync Save to Cloud")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    // Restore save from "cloud"
                    Button(onClick = {
                        val profileId = UserManager.getProfileId(context)
                        scope.launch {
                            CloudSyncManager.restoreSaves(context, profileId)
                            // After restore, update state
                            hasSaveState.value = SaveManager.hasSave(context, profileId, game.id)
                            Toast.makeText(context, "Save restored from cloud", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text(text = "Restore Save from Cloud")
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "Game not found", style = MaterialTheme.typography.bodyLarge)
                Button(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) {
                    Text(text = "Back")
                }
            }
        }
    }
}