package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avenor.gamestore.R
import com.avenor.gamestore.models.Game
import com.avenor.gamestore.data.GameRepository

/**
 * Home screen shows a list of featured games. Users can tap a game to view details.
 *
 * @param onGameSelected Callback when a game is tapped.
 * @param onCartClick Callback when the cart icon is tapped.
 * @param onInstallManagerClick Callback when the install manager icon is tapped.
 */
@Composable
fun HomeScreen(
    onGameSelected: (Int) -> Unit,
    onCartClick: () -> Unit,
    onInstallManagerClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val context = LocalContext.current
    // Preload games via network. Using mutable state allows updating when
    // asynchronous fetch completes. The list is initially empty.
    val gamesState = remember { mutableStateOf<List<Game>>(emptyList()) }
    val scope = rememberCoroutineScope()
    // Load games on first composition
    LaunchedEffect(Unit) {
        val list = GameRepository.getGames(context)
        gamesState.value = list
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(text = "Avenor Store", fontWeight = FontWeight.Bold) },
            actions = {
                IconButton(onClick = onInstallManagerClick) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = "Downloads"
                    )
                }
                IconButton(onClick = onCartClick) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingCart,
                        contentDescription = "Cart"
                    )
                }
                // Settings icon to open profile settings
                IconButton(onClick = onSettingsClick) {
                    Icon(
                        imageVector = androidx.compose.material.icons.filled.Settings,
                        contentDescription = "Settings"
                    )
                }
            },
            colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(gamesState.value) { game ->
                GameListItem(game = game, onClick = { onGameSelected(game.id) })
            }
        }
    }
}

@Composable
private fun GameListItem(game: Game, onClick: () -> Unit) {
    val context = LocalContext.current
    // Resolve drawable id by name.
    val imageId = remember(game.thumbnail) {
        context.resources.getIdentifier(game.thumbnail, "drawable", context.packageName)
    }
    Card(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth(),
        onClick = onClick,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (imageId != 0) {
                Image(
                    painter = painterResource(id = imageId),
                    contentDescription = game.title,
                    modifier = Modifier.size(64.dp)
                )
            }
            Spacer(modifier = Modifier.size(16.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = game.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                // Show a short description instead of price since the demo catalogue does not have pricing yet
                Text(
                    text = game.shortDescription,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2
                )
            }
        }
    }
}