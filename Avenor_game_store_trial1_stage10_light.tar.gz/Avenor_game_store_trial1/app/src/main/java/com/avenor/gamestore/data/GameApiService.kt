package com.avenor.gamestore.data

import com.avenor.gamestore.models.Game
import retrofit2.http.GET

/**
 * Retrofit API interface definition for communicating with the backend. Only
 * endpoints required by the store client are defined here. Additional
 * functionality (publishing, stats) is implemented in other applications.
 */
interface GameApiService {
    /**
     * Return the list of games available in the store. The backend will
     * embed all metadata including download URLs for each game. The JWT
     * authorisation header is added automatically by the HTTP client.
     */
    @GET("/games")
    suspend fun getGames(): List<Game>
}