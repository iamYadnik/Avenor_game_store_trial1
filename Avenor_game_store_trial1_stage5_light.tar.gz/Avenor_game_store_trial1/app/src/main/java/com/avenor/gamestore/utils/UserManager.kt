package com.avenor.gamestore.utils

import android.content.Context

/**
 * Manages the current user profile. For this MVP a single “default” profile is
 * generated the first time the app runs. In future iterations this can be
 * extended to support multiple profiles, guest accounts, cloud‑synced
 * identities, etc.
 */
object UserManager {
    private const val PREF_NAME = "user_prefs"
    private const val KEY_PROFILE_ID = "profile_id"

    /**
     * Retrieve the current profile ID. If none has been set yet, a default
     * profile is created and persisted.
     *
     * @param context A valid application context.
     * @return A non‑empty string representing the profile identifier.
     */
    fun getProfileId(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        var id = prefs.getString(KEY_PROFILE_ID, null)
        if (id.isNullOrEmpty()) {
            id = "default"
            prefs.edit().putString(KEY_PROFILE_ID, id).apply()
        }
        return id
    }

    /**
     * Assign a new profile ID. Use this when implementing user account
     * switching. Currently unused but included for completeness.
     */
    fun setProfileId(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PROFILE_ID, id).apply()
    }
}