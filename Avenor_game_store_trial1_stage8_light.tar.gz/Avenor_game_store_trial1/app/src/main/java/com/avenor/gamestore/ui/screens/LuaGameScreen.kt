package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
// We don't use rememberCoroutineScope or launch directly because
// the LuaRuntimeManager manages its own coroutine scope internally.
import androidx.compose.ui.unit.dp
import java.io.File
import com.avenor.gamestore.utils.LuaRuntimeManager

/**
 * A simple placeholder screen for Lua‑based games.  Lists any `.lua` files
 * extracted in the game folder and informs the user that a Lua interpreter
 * will be integrated in a future release.  A back button returns the user
 * to the store.  When real Lua support is added, this screen can be
 * replaced with a proper runtime that loads and executes the selected
 * scripts.
 *
 * @param gameId Identifier of the game whose folder should be scanned for
 *               Lua scripts.
 * @param onBack Callback invoked when the user taps the back button.
 */
@Composable
fun LuaGameScreen(gameId: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    // Enumerate .lua files in the extracted game directory. We store the absolute
    // path along with the file name for running the script later.
    val luaFiles = remember(gameId) {
        val dir = File(context.filesDir, "games/$gameId")
        dir.listFiles()?.filter { it.extension.equals("lua", ignoreCase = true) }
            ?.map { it to it.name } ?: emptyList()
    }
    // Create a LuaRuntimeManager for this game ID
    val runtime = remember(gameId) { LuaRuntimeManager(context, gameId) }
    val logs = runtime.logs.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        // Header
        Text(
            text = "Lua Game",
            style = MaterialTheme.typography.headlineMedium
        )
        // List of available Lua scripts with run buttons
        if (luaFiles.isEmpty()) {
            Text(
                text = "No Lua files detected.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            Text(
                text = "Select a script to run:",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
            LazyColumn(
                modifier = Modifier
                    .padding(top = 4.dp)
            ) {
                items(luaFiles) { (file, name) ->
                    // Each row: file name and a Run button
                    Column(
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Text(text = name, style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = {
                                // Run the selected Lua script
                                runtime.runScript(file.absolutePath)
                            },
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(text = "Run Script")
                        }
                    }
                }
            }
        }

        // Output log area
        Text(
            text = "Output:",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 12.dp)
        )
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(top = 4.dp)
        ) {
            items(logs.value) { line ->
                Text(text = line, style = MaterialTheme.typography.bodySmall)
            }
        }

        // Footer with actions
        Column(
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Button(
                onClick = { runtime.clearLogs() },
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(text = "Clear Output")
            }
            Button(
                onClick = onBack,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(text = "Back to Store")
            }
        }
    }
}