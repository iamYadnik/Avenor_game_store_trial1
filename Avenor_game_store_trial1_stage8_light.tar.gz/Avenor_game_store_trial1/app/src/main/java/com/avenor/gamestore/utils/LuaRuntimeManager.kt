package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.luaj.vm2.*
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.TwoArgFunction
import org.luaj.vm2.lib.ZeroArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.File

/**
 * LuaRuntimeManager is responsible for executing Lua scripts within the
 * app. It wraps the LuaJ interpreter and exposes a limited set of
 * functions (print, save_state, load_state, get_profile_id) to the
 * script environment. Script output is delivered to observers via a
 * StateFlow of log messages.
 *
 * Each instance of this class is tied to a single game ID, which is
 * used when saving and loading state via [SaveManager].
 */
class LuaRuntimeManager(
    private val context: Context,
    private val gameId: Int
) {
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    /**
     * Executes a Lua script located at the given file path. The
     * execution occurs on a background thread. Any output produced by
     * calls to `print` within the script will be captured and appended
     * to the logs.
     *
     * @param scriptPath Absolute path of the Lua script file to run.
     */
    fun runScript(scriptPath: String) {
        // Launch the interpreter on an IO thread so the UI stays responsive
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Set up a new environment with the standard library
                val globals: Globals = JsePlatform.standardGlobals()

                // Override the print function so that Lua print calls
                // append to our logs instead of stdout
                globals.set("print", object : VarArgFunction() {
                    override fun invoke(args: Varargs?): Varargs {
                        val builder = StringBuilder()
                        val n = args?.narg() ?: 0
                        for (i in 1..n) {
                            val v = args?.arg(i)
                            if (i > 1) builder.append("\t")
                            builder.append(v?.tojstring())
                        }
                        appendLog(builder.toString())
                        return LuaValue.NIL
                    }
                })

                // Expose save_state(key, value) to Lua
                globals.set("save_state", object : TwoArgFunction() {
                    override fun call(key: LuaValue, value: LuaValue): LuaValue {
                        val profileId = UserManager.getProfileId(context)
                        // Save JSON object storing key->value pair
                        val data = value.tojstring()
                        SaveManager.saveGameState(context, profileId, gameId, data)
                        return LuaValue.NIL
                    }
                })

                // Expose load_state(key) -> value to Lua
                globals.set("load_state", object : OneArgFunction() {
                    override fun call(key: LuaValue): LuaValue {
                        val profileId = UserManager.getProfileId(context)
                        val data = SaveManager.loadGameState(context, profileId, gameId)
                        return if (data != null) LuaValue.valueOf(data) else LuaValue.NIL
                    }
                })

                // Expose get_profile_id() -> string
                globals.set("get_profile_id", object : ZeroArgFunction() {
                    override fun call(): LuaValue {
                        return LuaValue.valueOf(UserManager.getProfileId(context))
                    }
                })

                // Load and execute the script file
                val file = File(scriptPath)
                if (file.exists()) {
                    val chunk = globals.loadfile(file.absolutePath)
                    chunk.call()
                } else {
                    appendLog("Script file not found: $scriptPath")
                }
            } catch (e: Exception) {
                appendLog("Lua error: ${e.message}")
            }
        }
    }

    /**
     * Clears the current log. Use this when the user presses "Clear Output".
     */
    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun appendLog(message: String) {
        // Append message to current logs atomically
        _logs.value = _logs.value + message
    }
}