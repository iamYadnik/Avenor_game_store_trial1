package com.avenor.gamestore.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Data transfer objects used for communicating with the payment
 * endpoints on the backend.  These classes mirror the request and
 * response bodies defined in the FastAPI server.
 */

@Serializable
data class CreateOrderRequest(
    @SerialName("game_id") val gameId: Int,
    val amount: Float
)

@Serializable
data class VerifyPaymentRequest(
    @SerialName("order_id") val orderId: String,
    val signature: String
)

@Serializable
data class OrderResponse(
    @SerialName("order_id") val orderId: String,
    val status: String
)