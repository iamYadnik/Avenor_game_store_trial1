package com.avenor.gamestore.data

import android.content.Context
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Interceptor
import okhttp3.Response
import retrofit2.Retrofit

/**
 * Provides Retrofit service instances configured with base URL, JSON
 * converter and an interceptor to inject the JWT bearer token stored in
 * shared preferences. The network layer is defined as a separate object
 * to keep repository and UI code decoupled from retrofit specifics.
 */
object NetworkModule {
    private const val BASE_URL = "https://example.com/api" // replace with real backend URL

    /**
     * Builds and returns a singleton Retrofit instance. The OkHttp client
     * automatically adds an Authorization header when a JWT is available.
     */
    private fun provideRetrofit(context: Context): Retrofit {
        val contentType = "application/json".toMediaType()
        val client = OkHttpClient.Builder()
            .addInterceptor(object : Interceptor {
                override fun intercept(chain: Interceptor.Chain): Response {
                    val original = chain.request()
                    val builder = original.newBuilder()
                    // Retrieve token from shared preferences via UserManager
                    val token = try {
                        com.avenor.gamestore.utils.UserManager.getAuthToken(context)
                    } catch (e: Exception) {
                        null
                    }
                    if (!token.isNullOrEmpty()) {
                        builder.header("Authorization", "Bearer $token")
                    }
                    return chain.proceed(builder.build())
                }
            })
            .build()
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(Json { ignoreUnknownKeys = true }.asConverterFactory(contentType))
            .build()
    }

    /**
     * Provide the GameApiService using the configured retrofit instance.
     */
    fun provideGameApiService(context: Context): GameApiService {
        return provideRetrofit(context).create(GameApiService::class.java)
    }
}