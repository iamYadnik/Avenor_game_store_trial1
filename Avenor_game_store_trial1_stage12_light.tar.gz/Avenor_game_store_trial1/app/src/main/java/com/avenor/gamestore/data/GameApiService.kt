package com.avenor.gamestore.data

import com.avenor.gamestore.models.Game
import retrofit2.http.GET

/**
 * Retrofit API interface definition for communicating with the backend. Only
 * endpoints required by the store client are defined here. Additional
 * functionality (publishing, stats) is implemented in other applications.
 */
interface GameApiService {
    /**
     * Return the list of games available in the store. The backend will
     * embed all metadata including download URLs for each game. The JWT
     * authorisation header is added automatically by the HTTP client.
     */
    @GET("/games")
    suspend fun getGames(): List<Game>

    /**
     * Create a payment order for purchasing a game.  The backend
     * returns a dummy Razorpay order id and created status.  The
     * implementation may throw an exception on network error.
     */
    @retrofit2.http.POST("/payments/create_order")
    suspend fun createOrder(
        @retrofit2.http.Body request: CreateOrderRequest
    ): OrderResponse

    /**
     * Verify a payment once the user completes the payment flow.  The
     * backend marks the payment as completed.  In dummy mode any
     * signature is accepted.
     */
    @retrofit2.http.POST("/payments/verify_payment")
    suspend fun verifyPayment(
        @retrofit2.http.Body request: VerifyPaymentRequest
    ): OrderResponse
}