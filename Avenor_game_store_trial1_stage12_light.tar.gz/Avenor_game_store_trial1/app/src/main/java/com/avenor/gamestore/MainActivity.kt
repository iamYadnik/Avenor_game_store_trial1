package com.avenor.gamestore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import com.avenor.gamestore.ui.navigation.AppNavHost
import com.avenor.gamestore.ui.theme.AvenorGameStoreTheme

/**
 * Entry point for the application. Uses Jetpack Compose to define the UI hierarchy.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AvenorGameStoreTheme {
                Surface {
                    AppNavHost()
                }
            }
        }
    }
}