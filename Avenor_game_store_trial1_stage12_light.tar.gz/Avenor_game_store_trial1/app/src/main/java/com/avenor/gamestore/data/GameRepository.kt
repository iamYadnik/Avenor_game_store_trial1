package com.avenor.gamestore.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.BufferedReader

/**
 * Repository responsible for loading game data. Currently reads from a JSON asset bundled with the app.
 * Future versions can swap this implementation with a network backed API or database.
 */
import com.avenor.gamestore.models.Game

object GameRepository {
    private const val GAME_ASSET_FILE = "games.json"

    /**
     * Load the list of games from the bundled JSON file. This is used as a
     * fallback when the backend API is unreachable or fails. In the future
     * this method may be removed entirely once the store relies solely on
     * server–side metadata.
     */
    private fun loadLocalGames(context: Context): List<Game> {
        return try {
            val jsonString = context.assets.open(GAME_ASSET_FILE).bufferedReader().use(BufferedReader::readText)
            Json { ignoreUnknownKeys = true }.decodeFromString(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * Retrieve the list of available games. The repository will attempt to
     * fetch the catalogue from the backend API first; if the network call
     * fails, it falls back to reading from the bundled JSON. This method
     * should be called from within a coroutine scope.
     */
    suspend fun getGames(context: Context): List<Game> {
        // Attempt to fetch from backend
        return try {
            val api = NetworkModule.provideGameApiService(context)
            val response = api.getGames()
            if (response.isNotEmpty()) {
                response
            } else {
                loadLocalGames(context)
            }
        } catch (e: Exception) {
            // Fallback to local JSON
            loadLocalGames(context)
        }
    }

    /**
     * Fetch a single game by ID. This makes a network request if possible and
     * falls back to local data otherwise.
     */
    suspend fun getGameById(context: Context, id: Int): Game? {
        return getGames(context).find { it.id == id }
    }
}