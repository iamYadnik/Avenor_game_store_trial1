package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Simulated cloud sync manager.  In a real implementation these methods
 * would interact with a remote server (for example a REST API, Firebase
 * Storage or a Git repository) to upload/download save data.  This MVP
 * approximates that behaviour by creating a ZIP archive of the saves
 * directory and storing it under `files/cloud_saves/{profileId}.zip`.
 * Restoring a save unpacks the archive back into the local saves
 * directory.  All operations are performed on a background thread via
 * Kotlin coroutines.
 */
object CloudSyncManager {

    /**
     * Returns a File reference to the directory where cloud archives are
     * stored locally.  The directory is created if necessary.
     */
    private fun getCloudDir(context: Context): File {
        val dir = File(context.filesDir, "cloud_saves")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Compress the save directory for the given profile into a ZIP file
     * under the cloud directory.  Existing archives will be replaced.
     *
     * @param context Application context used to resolve file paths.
     * @param profileId The user profile whose saves are being backed up.
     */
    suspend fun backupSaves(context: Context, profileId: String) {
        withContext(Dispatchers.IO) {
            val saveDir = File(context.filesDir, "saves/$profileId")
            val cloudDir = getCloudDir(context)
            if (!saveDir.exists()) {
                // Nothing to back up
                return@withContext
            }
            val zipFile = File(cloudDir, "$profileId.zip")
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                saveDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    val entryName = file.relativeTo(saveDir).path
                    val entry = ZipEntry(entryName)
                    zos.putNextEntry(entry)
                    file.inputStream().use { input ->
                        input.copyTo(zos)
                    }
                    zos.closeEntry()
                }
            }
        }
    }

    /**
     * Restore save data for the given profile from the local cloud archive.
     * If no archive exists this function silently does nothing.  Existing
     * save data will be replaced by the contents of the archive.
     *
     * @param context Application context used to resolve file paths.
     * @param profileId The user profile whose saves are being restored.
     */
    suspend fun restoreSaves(context: Context, profileId: String) {
        withContext(Dispatchers.IO) {
            val cloudDir = getCloudDir(context)
            val zipFile = File(cloudDir, "$profileId.zip")
            if (!zipFile.exists()) {
                // Nothing to restore
                return@withContext
            }
            // Destination directory
            val saveDir = File(context.filesDir, "saves/$profileId")
            // Remove existing saves
            if (saveDir.exists()) {
                saveDir.deleteRecursively()
            }
            saveDir.mkdirs()
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val filePath = File(saveDir, entry.name)
                    if (entry.isDirectory) {
                        filePath.mkdirs()
                    } else {
                        filePath.parentFile?.mkdirs()
                        FileOutputStream(filePath).use { fos ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            var length: Int
                            while (zis.read(buffer).also { length = it } > 0) {
                                fos.write(buffer, 0, length)
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
    }
}