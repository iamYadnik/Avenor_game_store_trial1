package com.avenor.gamestore.data

import kotlinx.serialization.Serializable

/**
 * Data model representing a game in the store.
 *
 * @param id Unique identifier for the game.
 * @param title Human‑readable title of the game.
 * @param description Full description of the game. This can be several paragraphs long.
 * @param price Price of the game in local currency. For this MVP we use a simple numeric value.
 * @param thumbnail Name of the drawable resource for the game thumbnail (without the file extension).
 * @param screenshots List of drawable names representing screenshots. Screenshots are optional and can be empty.
 */
@Serializable
data class Game(
    val id: Int,
    val title: String,
    val description: String,
    val price: Float,
    val thumbnail: String,
    val screenshots: List<String> = emptyList()
)