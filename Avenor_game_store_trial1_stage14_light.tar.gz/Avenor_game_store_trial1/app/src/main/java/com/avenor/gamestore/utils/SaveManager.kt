package com.avenor.gamestore.utils

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.io.File

/**
 * Utility for persisting and retrieving game save data. Games can serialize
 * their internal state to a JSON string and store it under a user‑specific
 * directory. The save files are namespaced by both the profile ID and the
 * game ID, enabling multiple users to play the same game without
 * interfering with each other.
 */
object SaveManager {

    // SharedPreferences name for storing per‑profile encryption keys
    private const val KEY_PREFS_NAME = "profile_keys"
    private const val KEY_PREFIX = "key_"

    /**
     * Retrieve or generate the AES secret key for a given profile.  Keys are
     * 256 bits long (32 bytes) and encoded with Base64 when stored.  If a
     * key does not yet exist for the profile it will be created and
     * persisted to SharedPreferences.
     */
    private fun getSecretKey(context: Context, profileId: String): SecretKeySpec {
        val prefs = context.getSharedPreferences(KEY_PREFS_NAME, Context.MODE_PRIVATE)
        val keyName = KEY_PREFIX + profileId
        var keyString = prefs.getString(keyName, null)
        if (keyString.isNullOrEmpty()) {
            val keyBytes = ByteArray(32)
            SecureRandom().nextBytes(keyBytes)
            keyString = Base64.encodeToString(keyBytes, Base64.NO_WRAP)
            prefs.edit().putString(keyName, keyString).apply()
        }
        val decoded = Base64.decode(keyString, Base64.NO_WRAP)
        return SecretKeySpec(decoded, "AES")
    }

    /**
     * Encrypt a plain string using AES/CBC/PKCS5Padding.  A fresh IV is
     * generated for each encryption and prepended to the ciphertext,
     * separated by a colon when encoded to Base64.  The resulting
     * string can be safely stored as text.
     */
    private fun encryptString(plainText: String, key: SecretKeySpec): String {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val ivBytes = ByteArray(16)
        SecureRandom().nextBytes(ivBytes)
        val ivSpec = IvParameterSpec(ivBytes)
        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec)
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val ivString = Base64.encodeToString(ivBytes, Base64.NO_WRAP)
        val encString = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        return "$ivString:$encString"
    }

    /**
     * Decrypt a string produced by [encryptString].  Returns null if
     * decryption fails (for example if the input is not in the expected
     * format or the key/IV are incorrect).
     */
    private fun decryptString(cipherText: String, key: SecretKeySpec): String? {
        val parts = cipherText.split(":")
        if (parts.size != 2) return null
        return try {
            val ivBytes = Base64.decode(parts[0], Base64.NO_WRAP)
            val encBytes = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            val ivSpec = IvParameterSpec(ivBytes)
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec)
            val decrypted = cipher.doFinal(encBytes)
            String(decrypted, Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Get (and create if necessary) the directory where save files for a
     * particular user profile are stored.
     *
     * @param context A valid application context.
     * @param profileId Unique identifier for the user profile.
     * @return The File pointing to the directory `files/saves/{profileId}`.
     */
    private fun getSaveDir(context: Context, profileId: String): File {
        val dir = File(context.filesDir, "saves/$profileId")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Persist the provided game state to a file. Existing files will be
     * overwritten. If the directory hierarchy does not exist it will be
     * created automatically.
     *
     * @param context A valid application context.
     * @param profileId Unique identifier for the user profile.
     * @param gameId Identifier of the game whose state is being saved.
     * @param data Arbitrary string (typically JSON) representing the game state.
     */
    fun saveGameState(context: Context, profileId: String, gameId: Int, data: String) {
        val file = File(getSaveDir(context, profileId), "$gameId.json")
        // Encrypt save data before writing to disk
        val key = getSecretKey(context, profileId)
        val encrypted = encryptString(data, key)
        file.writeText(encrypted)
    }

    /**
     * Retrieve saved state for a game. Returns null if no save exists.
     *
     * @param context A valid application context.
     * @param profileId Unique identifier for the user profile.
     * @param gameId Identifier of the game whose state is being loaded.
     * @return The raw save string, or null if none exists.
     */
    fun loadGameState(context: Context, profileId: String, gameId: Int): String? {
        val file = File(getSaveDir(context, profileId), "$gameId.json")
        if (!file.exists()) return null
        val raw = file.readText()
        val key = getSecretKey(context, profileId)
        // Attempt to decrypt; if decryption fails assume plain text for backwards
        // compatibility and return raw contents
        val decrypted = decryptString(raw, key)
        return decrypted ?: raw
    }

    /**
     * Remove a game's saved state entirely. This can be used to implement
     * “Clear Save” functionality.
     *
     * @param context A valid application context.
     * @param profileId Unique identifier for the user profile.
     * @param gameId Identifier of the game whose save file should be deleted.
     */
    fun clearGameState(context: Context, profileId: String, gameId: Int) {
        val file = File(getSaveDir(context, profileId), "$gameId.json")
        if (file.exists()) {
            file.delete()
        }
    }

    /**
     * Check whether a save file exists for the given game/profile.
     *
     * @param context A valid application context.
     * @param profileId Unique identifier for the user profile.
     * @param gameId Identifier of the game.
     * @return True if a save file exists; false otherwise.
     */
    fun hasSave(context: Context, profileId: String, gameId: Int): Boolean {
        val file = File(getSaveDir(context, profileId), "$gameId.json")
        return file.exists()
    }
}