package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.avenor.gamestore.data.GameRepository
import com.avenor.gamestore.data.DeveloperProfile
import kotlinx.coroutines.launch

/**
 * Screen displaying information about a developer (publisher).  Shows the
 * developer's avatar, name, bio and a list of their published games.
 */
@Composable
fun DeveloperProfileScreen(developerId: Int, onBack: () -> Unit, onGameSelected: (Int) -> Unit) {
    val context = LocalContext.current
    val profileState = remember { mutableStateOf<DeveloperProfile?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(developerId) {
        scope.launch {
            profileState.value = GameRepository.getDeveloper(context, developerId)
        }
    }

    val profile = profileState.value

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(text = profile?.name ?: "Developer", style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )
        if (profile != null) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                    // Avatar and bio
                    AsyncImage(
                        model = profile.avatarUrl,
                        contentDescription = profile.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    if (!profile.bio.isNullOrBlank()) {
                        Text(
                            text = profile.bio ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    Text(
                        text = "Games by this developer:",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                items(profile.games) { game ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(text = game.title, style = MaterialTheme.typography.bodyLarge)
                        Text(text = "Version: ${game.version}", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Engine: ${game.contentType}", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { onGameSelected(game.id) }, modifier = Modifier.padding(top = 4.dp)) {
                            Text(text = "View")
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "Loading...", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}