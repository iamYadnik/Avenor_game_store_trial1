package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/**
 * Handles creation, listing and activation of user profiles.  A profile
 * represents a local player identity and is identified by a UUID.  All
 * profile metadata is persisted to a JSON file under `files/profiles`
 * so that multiple profiles can be restored across app launches.  The
 * currently active profile ID is stored separately in SharedPreferences
 * so that other managers (e.g. SaveManager) can namespace data by
 * profile.
 */
object ProfileManager {

    // Preferences file used to store the active profile ID
    private const val PREF_NAME = "user_prefs"
    private const val KEY_ACTIVE_PROFILE_ID = "profile_id"

    /**
     * Simple data model for a profile.  Additional fields such as avatar
     * or last‑played timestamp can be added in the future.
     */
    @Serializable
    data class Profile(val id: String, val name: String)

    /**
     * Return the file where the list of profiles is stored.  The directory
     * is created if it does not already exist.
     */
    private fun getProfilesFile(context: Context): File {
        val dir = File(context.filesDir, "profiles")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return File(dir, "profiles.json")
    }

    /**
     * Load all profiles from disk.  If no profiles exist the returned list
     * will be empty.  The caller should ensure that a default profile is
     * created if required (see [getOrCreateDefaultProfile]).
     */
    fun getProfiles(context: Context): MutableList<Profile> {
        val file = getProfilesFile(context)
        return if (file.exists()) {
            val jsonString = file.readText()
            if (jsonString.isNotBlank()) {
                try {
                    Json.decodeFromString(jsonString)
                } catch (_: Exception) {
                    mutableListOf()
                }
            } else {
                mutableListOf()
            }
        } else {
            mutableListOf()
        }
    }

    /**
     * Persist the provided list of profiles to disk, overwriting any
     * previously stored list.  The list is serialized as JSON using
     * Kotlinx Serialization.
     */
    private fun saveProfiles(context: Context, profiles: List<Profile>) {
        val file = getProfilesFile(context)
        file.writeText(Json.encodeToString(profiles))
    }

    /**
     * Create a new profile with the given name.  A UUID is automatically
     * generated and the new profile is appended to the stored list.
     * If this is the first profile on disk, it is also set as the
     * active profile.
     *
     * @return The newly created Profile instance.
     */
    fun addProfile(context: Context, name: String): Profile {
        val profiles = getProfiles(context)
        val newProfile = Profile(UUID.randomUUID().toString(), name)
        profiles.add(newProfile)
        saveProfiles(context, profiles)

        // If no active profile is currently set, make the new one active
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val active = prefs.getString(KEY_ACTIVE_PROFILE_ID, null)
        if (active.isNullOrEmpty()) {
            setActiveProfileId(context, newProfile.id)
        }
        return newProfile
    }

    /**
     * Retrieve the identifier of the currently active profile.  Returns
     * null if none has been configured yet.  When the app starts you
     * should call [getOrCreateDefaultProfile] to ensure there is at least
     * one profile available.
     */
    fun getActiveProfileId(context: Context): String? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACTIVE_PROFILE_ID, null)
    }

    /**
     * Set the active profile ID.  This will cause subsequent calls
     * retrieving save data or other user‑specific information to use
     * this profile’s namespace.
     */
    fun setActiveProfileId(context: Context, profileId: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ACTIVE_PROFILE_ID, profileId).apply()
    }

    /**
     * Returns the current list of profiles.  If none exist a new
     * default profile is created and returned.  The default profile is
     * named "Player1" for convenience.
     */
    fun getOrCreateDefaultProfile(context: Context): Profile {
        var profiles = getProfiles(context)
        if (profiles.isEmpty()) {
            val profile = addProfile(context, "Player1")
            profiles = getProfiles(context)
            return profile
        }
        // Ensure active profile is set
        val active = getActiveProfileId(context)
        if (active.isNullOrEmpty()) {
            setActiveProfileId(context, profiles.first().id)
        }
        return profiles.first()
    }
}