package com.avenor.gamestore.data

import com.avenor.gamestore.models.Game
import retrofit2.http.GET

/**
 * Retrofit API interface definition for communicating with the backend. Only
 * endpoints required by the store client are defined here. Additional
 * functionality (publishing, stats) is implemented in other applications.
 */
interface GameApiService {
    /**
     * Return the list of games available in the store. The backend will
     * embed all metadata including download URLs for each game. The JWT
     * authorisation header is added automatically by the HTTP client.
     */
    @GET("/games")
    suspend fun getGames(): List<Game>

    /**
     * Create a payment order for purchasing a game.  The backend
     * returns a dummy Razorpay order id and created status.  The
     * implementation may throw an exception on network error.
     */
    @retrofit2.http.POST("/payments/create_order")
    suspend fun createOrder(
        @retrofit2.http.Body request: CreateOrderRequest
    ): OrderResponse

    /**
     * Verify a payment once the user completes the payment flow.  The
     * backend marks the payment as completed.  In dummy mode any
     * signature is accepted.
     */
    @retrofit2.http.POST("/payments/verify_payment")
    suspend fun verifyPayment(
        @retrofit2.http.Body request: VerifyPaymentRequest
    ): OrderResponse

    /**
     * Return the current user's game library.  Requires authentication.
     */
    @GET("/library/my_games")
    suspend fun getMyGames(): List<LibraryGame>

    /**
     * Submit a review or rating for a game.  The backend will upsert the
     * review and return a simple confirmation.
     */
    @retrofit2.http.POST("/reviews")
    suspend fun submitReview(@retrofit2.http.Body request: ReviewRequest): retrofit2.Response<Unit>

    /**
     * Fetch all reviews for the specified game.
     */
    @GET("/reviews/{gameId}")
    suspend fun getReviews(@retrofit2.http.Path("gameId") gameId: Int): List<GameReview>

    /**
     * Retrieve summary statistics (average rating, count) for a game.
     */
    @GET("/reviews/summary/{gameId}")
    suspend fun getReviewSummary(@retrofit2.http.Path("gameId") gameId: Int): ReviewSummary

    /**
     * Get details for a developer profile including list of games.
     */
    @GET("/developers/{developerId}")
    suspend fun getDeveloper(@retrofit2.http.Path("developerId") developerId: Int): DeveloperProfile

    /**
     * Get the version history for a game.  The gameId path parameter is
     * included in the prefix as the router is mounted under /games.
     */
    @GET("/games/{gameId}/versions")
    suspend fun getGameVersions(@retrofit2.http.Path("gameId") gameId: Int): List<GameVersionInfo>
}