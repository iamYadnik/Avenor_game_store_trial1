package com.avenor.gamestore.ui.screens

import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.avenor.gamestore.data.GameRepository
import com.avenor.gamestore.models.GameContentType
import com.avenor.gamestore.utils.SaveManager
import com.avenor.gamestore.utils.UserManager
import com.avenor.gamestore.ui.screens.LuaGameScreen
import java.io.File

/**
 * A simple screen that displays the contents of the game's launch file.
 *
 * The game assets are extracted to the app's internal storage by [GameAssetManager].
 * This screen reads the `launch.txt` file from the game's installation directory
 * and displays its contents. In a future iteration this would host the actual
 * contained runtime (Unity, Godot, HTML5, etc.).
 *
 * @param gameId Identifier of the installed game whose launch file should be read.
 * @param onBack Callback invoked when the user taps the back button.
 */
@Composable
fun GamePlayScreen(gameId: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    // Load the current game information from the repository. This provides metadata
    // such as the title and content type specified in games.json.
    val game = remember(gameId) {
        GameRepository.loadGames(context).find { it.id == gameId }
    }
    // Determine the content type by examining the extracted game directory. The
    // simple heuristic is:
    //   - If an index.html file exists, treat it as an HTML game.
    //   - Else if any .lua file exists, treat it as a Lua game.
    //   - Otherwise fall back to the type specified in the JSON or default to TEXT.
    val detectedContentType = remember(gameId) {
        val dir = File(context.filesDir, "games/$gameId")
        when {
            File(dir, "index.html").exists() -> GameContentType.HTML
            // Detect Godot games by presence of .pck file
            dir.listFiles()?.any { it.extension.equals("pck", ignoreCase = true) } == true -> GameContentType.GODOT
            dir.listFiles()?.any { it.extension.equals("lua", ignoreCase = true) } == true -> GameContentType.LUA
            else -> GameContentType.TEXT
        }
    }
    val contentType = remember(game, detectedContentType) {
        // Prefer the detected content type if it differs from TEXT; otherwise use
        // the type specified in the JSON (Game.contentType).  Finally default
        // to TEXT for unknown values.
        if (detectedContentType != GameContentType.TEXT) {
            detectedContentType
        } else {
            GameContentType.fromKey(game?.contentType)
        }
    }
    // Maintain fullscreen state. When true, hide the top bar.  We use a state
    // object so Compose recomposes when the user toggles fullscreen.
    val isFullScreen = remember { mutableStateOf(false) }
    // Preload the launch.txt message in case we fall back to text rendering.  If
    // the file does not exist, inform the user that the game must be installed.
    val launchMessage = remember(gameId) {
        val file = File(context.filesDir, "games/$gameId/launch.txt")
        if (file.exists()) file.readText() else "Game content not found. Please install the game first."
    }
    Column(modifier = Modifier.fillMaxSize()) {
        // Conditionally show the top app bar when not in fullscreen.  The top
        // bar contains the title and buttons for navigation and fullscreen
        // toggling.
        if (!isFullScreen.value) {
            TopAppBar(
                title = {
                    Text(
                        text = game?.title ?: "Playing Game $gameId",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { isFullScreen.value = !isFullScreen.value }) {
                        // Toggle between fullscreen icons depending on state
                        val icon = if (isFullScreen.value) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen
                        val desc = if (isFullScreen.value) "Exit Fullscreen" else "Enter Fullscreen"
                        Icon(imageVector = icon, contentDescription = desc)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        }
        // Content area occupies remaining space.  Choose the correct renderer
        // based on the determined [contentType].
        when (contentType) {
            GameContentType.HTML -> {
                // Render HTML content in a WebView.  We embed an Android
                // WebView inside Compose via AndroidView.  Before loading the
                // HTML file we expose a small JavaScript API so the game can
                // persist and restore save data.  The API exposes two
                // functions: saveGameState(data: String) and loadGameState():
                // String.  Save data is stored under the current user
                // profile using [SaveManager].
                AndroidView(
                    factory = { ctx ->
                        // Define a JavaScript bridge with @JavascriptInterface
                        class GameJsBridge(private val context: Context) {
                            @JavascriptInterface
                            fun saveGameState(data: String?) {
                                val profileId = UserManager.getProfileId(context)
                                // Data may be null if called incorrectly
                                val state = data ?: ""
                                SaveManager.saveGameState(context, profileId, gameId, state)
                            }

                            @JavascriptInterface
                            fun loadGameState(): String {
                                val profileId = UserManager.getProfileId(context)
                                return SaveManager.loadGameState(context, profileId, gameId) ?: ""
                            }
                        }
                        WebView(ctx).apply {
                            val settings: WebSettings = this.settings
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = true
                            settings.allowFileAccessFromFileURLs = true
                            settings.allowUniversalAccessFromFileURLs = true
                            // Inject the bridge under the name "android"
                            addJavascriptInterface(GameJsBridge(ctx), "android")
                            // Load index.html from the game's directory
                            val file = File(ctx.filesDir, "games/$gameId/index.html")
                            loadUrl("file://" + file.path)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                )
                // Simple in‑game menu at bottom to return to the store
                Column(
                    modifier = Modifier
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(onClick = onBack) {
                        Text(text = "Back to Store")
                    }
                }
            }
            GameContentType.LUA -> {
                // Delegate to a dedicated screen for Lua games.  This
                // composable displays the list of Lua scripts and a
                // placeholder message.
                LuaGameScreen(gameId = gameId, onBack = onBack)
            }
            GameContentType.GODOT -> {
                // Placeholder for Godot games.  Currently there is no
                // embedded Godot runtime, so we inform the user and
                // list the files in the game directory for debugging.
                val dir = File(context.filesDir, "games/$gameId")
                val files = remember(gameId) { dir.list()?.toList() ?: emptyList() }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "Godot game installed", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Runtime coming soon", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    // List files for debugging
                    files.forEach { fileName ->
                        Text(text = fileName, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = onBack) {
                        Text(text = "Back to Store")
                    }
                }
            }
            GameContentType.TEXT, else -> {
                // Fallback: display the launch message in a simple column.  This
                // branch handles plain text games or unknown content types.
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = launchMessage, style = MaterialTheme.typography.bodyLarge)
                    Button(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) {
                        Text(text = "Back to Store")
                    }
                }
            }
        }
    }
}