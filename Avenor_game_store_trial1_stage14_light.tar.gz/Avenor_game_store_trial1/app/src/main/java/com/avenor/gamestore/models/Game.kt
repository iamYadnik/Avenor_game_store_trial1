package com.avenor.gamestore.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Data model representing a game entry in the store catalogue.
 *
 * All fields are serialized from JSON via Kotlinx Serialization. Optional fields
 * may be null depending on the JSON provided.
 */
@Serializable
data class Game(
    val id: Int,
    val title: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("full_description") val fullDescription: String,
    val developer: String,
    val genre: String,
    @SerialName("cover_image_url") val coverImageUrl: String,
    @SerialName("preview_video_url") val previewVideoUrl: String? = null,
    @SerialName("game_asset_zip_url") val gameAssetZipUrl: String,
    @SerialName("entry_point") val entryPoint: String,
    /**
     * Name of a local drawable resource used for thumbnail display. This is not
     * part of the provided JSON but is included to support local assets.
     */
    val thumbnail: String = ""

    ,
    /**
     * Remote download URL for the game assets. When present, the app will
     * download the game archive from this URL instead of loading a bundled
     * asset. This allows the store to fetch games on demand from the backend.
     */
    @SerialName("download_url")
    val downloadUrl: String? = null

    ,
    /**
     * Remote cover art URL returned by the backend.  This value will
     * override [coverImageUrl] when present.  It is mapped from the
     * `cover_url` field in JSON and may be null if not provided.
     */
    @SerialName("cover_url")
    val coverUrl: String? = null

    ,
    /**
     * Remote video URL returned by the backend.  When provided, the game
     * detail screen should use this value for the preview video instead of
     * [previewVideoUrl].  It is mapped from the `video_url` field in JSON.
     */
    @SerialName("video_url")
    val videoUrl: String? = null

    ,
    /**
     * The type of content this game includes. Recognised values are "html",
     * "lua" and "text". This allows the runtime shell to decide which
     * interpreter or renderer to use when launching the game. Defaults to
     * "text" if omitted.
     */
    @SerialName("content_type")
    val contentType: String = "text"

    ,

    /**
     * Semantic version string representing the release of this game.  The
     * backend may update this value when a new version is published.  The
     * app should display it on the game detail screen and prompt the user
     * to update when their installed version is older.
     */
    @SerialName("version")
    val version: String = "1.0.0"

    ,

    /**
     * Human‑readable changelog describing the differences between this
     * version and the previous one.  May be null if the publisher did not
     * provide a changelog.
     */
    @SerialName("changelog")
    val changelog: String? = null

    ,

    /**
     * Optional URL pointing at a differential patch file.  When present
     * the app can download this patch to update the installed game
     * rather than re‑downloading the entire archive.  The backend
     * controls whether a patch is available.
     */
    @SerialName("patch_url")
    val patchUrl: String? = null

    ,
    /**
     * Flag indicating whether the game currently has saved data. This value
     * can be updated at runtime based on save file existence via
     * [com.avenor.gamestore.utils.SaveManager.hasSave]. Defaults to false
     * when not specified in the JSON.
     */
    @SerialName("has_save_data")
    val hasSaveData: Boolean = false
)