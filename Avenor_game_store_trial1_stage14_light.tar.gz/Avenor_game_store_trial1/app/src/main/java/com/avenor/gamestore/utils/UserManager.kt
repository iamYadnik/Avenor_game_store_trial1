package com.avenor.gamestore.utils

import android.content.Context

/**
 * Manages the current user profile. For this MVP a single “default” profile is
 * generated the first time the app runs. In future iterations this can be
 * extended to support multiple profiles, guest accounts, cloud‑synced
 * identities, etc.
 */
object UserManager {
    /**
     * Retrieve the ID of the currently active profile.  Delegates to
     * [ProfileManager].  If no profiles exist this will create a
     * default profile named "Player1".
     *
     * @param context A valid application context.
     * @return A non‑empty string representing the profile identifier.
     */
    fun getProfileId(context: Context): String {
        // Ensure at least one profile exists and get the active profile ID
        val defaultProfile = ProfileManager.getOrCreateDefaultProfile(context)
        return ProfileManager.getActiveProfileId(context) ?: defaultProfile.id
    }

    /**
     * Assign a new active profile ID.  Delegates to [ProfileManager].
     */
    fun setProfileId(context: Context, id: String) {
        ProfileManager.setActiveProfileId(context, id)
    }

    /**
     * Obtain the current authentication token stored for the user. During
     * development this token is generated at login and persisted in
     * SharedPreferences under the key "auth_token". If no token has been
     * stored the function returns null.
     */
    fun getAuthToken(context: Context): String? {
        val prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        return prefs.getString("auth_token", null)
    }

    /**
     * Persist a new authentication token. This helper can be called after
     * completing a login flow to store the issued JWT for subsequent API
     * requests.
     */
    fun setAuthToken(context: Context, token: String?) {
        val prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("auth_token", token).apply()
    }
}