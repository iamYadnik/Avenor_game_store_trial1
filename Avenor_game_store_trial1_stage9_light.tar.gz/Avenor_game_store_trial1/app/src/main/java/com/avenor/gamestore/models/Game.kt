package com.avenor.gamestore.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Data model representing a game entry in the store catalogue.
 *
 * All fields are serialized from JSON via Kotlinx Serialization. Optional fields
 * may be null depending on the JSON provided.
 */
@Serializable
data class Game(
    val id: Int,
    val title: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("full_description") val fullDescription: String,
    val developer: String,
    val genre: String,
    @SerialName("cover_image_url") val coverImageUrl: String,
    @SerialName("preview_video_url") val previewVideoUrl: String? = null,
    @SerialName("game_asset_zip_url") val gameAssetZipUrl: String,
    @SerialName("entry_point") val entryPoint: String,
    /**
     * Name of a local drawable resource used for thumbnail display. This is not
     * part of the provided JSON but is included to support local assets.
     */
    val thumbnail: String = ""

    ,
    /**
     * The type of content this game includes. Recognised values are "html",
     * "lua" and "text". This allows the runtime shell to decide which
     * interpreter or renderer to use when launching the game. Defaults to
     * "text" if omitted.
     */
    @SerialName("content_type")
    val contentType: String = "text"

    ,
    /**
     * Flag indicating whether the game currently has saved data. This value
     * can be updated at runtime based on save file existence via
     * [com.avenor.gamestore.utils.SaveManager.hasSave]. Defaults to false
     * when not specified in the JSON.
     */
    @SerialName("has_save_data")
    val hasSaveData: Boolean = false
)