# Avenor Game Store Trial 1

This project is an open‑source Android application that serves as a lightweight game store, reminiscent of platforms like **Steam Deck** or the **Nintendo eShop**.  It is designed for indie and single‑player titles rather than ad‑based casual games.  The goal of this MVP is to demonstrate a console‑style browsing experience using modern Android technologies and to provide a clean foundation for future features such as downloads, cloud saves and subscriptions.

## ✨ Features

This second milestone builds upon the initial skeleton UI and introduces a **game catalogue with a contained runtime**.  Major capabilities include:

- **Console‑style UI** built with [Jetpack Compose](https://developer.android.com/jetpack/compose), optimised for full‑screen/gamepad navigation.  Navigate with touch, mouse or (in the future) D‑pad/joystick.
- **Login screen** with a “continue as guest” option (authentication hooks prepared for later).
- **Home screen** displaying a list of six demo games parsed from a local JSON asset (`games.json`).  Each item shows a title, short description and thumbnail.
- **Game detail page** that presents the full description, developer and genre of a selected title.  From here users can:
  * **Try Demo** – a lightweight button that opens a stub gameplay screen (no download required).
- **Install / Play Now** – downloads and extracts a ZIP archive from the app’s assets into internal storage using the built‑in `GameAssetManager`.  Once installed, the button changes to “Play Now” and launches the contained runtime.
- **Game Runtime Shell** – `GamePlayScreen` automatically inspects the installed game directory to decide how to run the content.  If an `index.html` file is present the runtime spins up an embedded WebView to render the game (including a fullscreen toggle and a simple in‑game menu).  If any `.lua` scripts are found a placeholder is displayed until a Lua interpreter is integrated.  Otherwise it falls back to the `content_type` declared in `games.json` and reads a `launch.txt` file as a plain text game.
- **Cart and download manager screens** remain placeholders but are still accessible from the app bar.
- **Modular architecture** separating data, UI, navigation and utility layers to simplify extension.

## 🛠️ Tech stack

- **Language:** Kotlin
- **UI Framework:** Jetpack Compose + Material 3
- **Navigation:** [AndroidX Navigation Compose](https://developer.android.com/jetpack/compose/navigation)
- **Serialization:** [Kotlinx Serialization](https://github.com/Kotlin/kotlinx.serialization) for loading games from a JSON asset
- **Minimum SDK:** 26 (Android 8.0)

## 📁 Project structure

The repo is organised as a typical Android project with an app module.  Key directories and files include:

```
Avenor_game_store_trial1/
├── build.gradle               # Project‑level Gradle script
├── settings.gradle            # Includes the :app module
├── app/
│   ├── build.gradle           # App module configuration, Compose enabled
│   ├── proguard-rules.pro     # ProGuard rules (empty for MVP)
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── assets/
│   │   │   ├── games.json         # Demo catalogue listing six games
│   │   │   └── game_assets/        # ZIP archives containing dummy game modules
│   │   │       ├── game1.zip
│   │   │       ├── …
│   │   │       └── game6.zip
│   │   ├── java/com/avenor/gamestore/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   └── GameRepository.kt (loads JSON)
│   │   │   ├── models/
│   │   │   │   └── Game.kt         # Data class for games
│   │   │   │   └── GameContentType.kt # Enum for classifying content types
│   │   │   ├── utils/
│   │   │   │   └── GameAssetManager.kt (handles ZIP extraction)
│   │   │   ├── ui/
│   │   │   │   ├── navigation/Navigation.kt (defines routes)
│   │   │   │   ├── screens/
│   │   │   │   │   ├── HomeScreen.kt         # Lists all games
│   │   │   │   │   ├── GameDetailScreen.kt   # Shows detailed info, install/play buttons
│   │   │   │   │   ├── GamePlayScreen.kt     # Displays the contained runtime
│   │   │   │   │   ├── LoginScreen.kt
│   │   │   │   │   ├── CartScreen.kt         # Placeholder
│   │   │   │   │   └── InstallManagerScreen.kt # Placeholder
│   │   │   │   └── theme/Theme.kt
│   │   └── res/drawable/
│   │       ├── game1.png
│   │       ├── game2.png
│   │       ├── …
│   │       └── game6.png       # Placeholder thumbnails
│   └── …
└── README.md
```

## 🚀 Building and running

This project is entirely offline‑compatible.  You can open it directly in **Android Studio (Hedgehog or later)** and run it on a device or emulator without any network access.

1. **Clone or extract** the repository into your local development workspace.
2. **Open** the project with Android Studio.
3. When prompted, **let Android Studio download the required Gradle wrappers** (internet is not required for local builds if your environment already has the Android Gradle plugin).
4. **Build and run** the `app` module on an emulator or physical device.

> **Note:** The Gradle scripts specify a Compose version (`compose_ui_version`) and Kotlin version in the top‑level `build.gradle`.  Update these values to the latest stable releases if you encounter compilation issues.

After installation, the game ZIP archives are unpacked into your app’s internal storage.  You can find the extracted folders under `data/data/<package>/files/games/{id}` on your device.  To try another game you simply tap “Install” or “Play Now” from the detail page – no external APKs are installed.

## 🧩 Extending the MVP

The current milestone lays the groundwork for a robust digital storefront.  The following ideas show how you can expand this project:

- **Backend/API integration:** Swap out `GameRepository` for a network‑backed implementation (Firebase, REST or GraphQL) to fetch game listings, prices and entitlements.  The Compose UI already reacts to lists of `Game` objects.
- **Download manager:** The `InstallManagerScreen` still shows a dummy message.  You could surface real download tasks here, track progress, allow pausing/canceling and verify checksums.  Integration with Android’s DownloadManager or WorkManager would make downloads robust.
- **Rich runtime support:** Instead of reading a `launch.txt` file, embed a Unity or Godot runtime in your app (as a library) and load game assets from the installed folder.  For HTML5/WebAssembly games, an embedded WebView can host the content.
- **Cloud saves, subscriptions, trials:** Build screens and logic to handle user entitlements.  Cloud save APIs, trial periods and subscription management can be layered on top of the existing architecture.
- **Improved assets:** The `res/drawable` folder contains six pixel‑art thumbnails generated for demonstration.  To use real game covers, download PNG files from sources like [OpenGameArt.org](https://opengameart.org/), [Itch.io](https://itch.io/) or [Kenney.nl](https://www.kenney.nl/assets).  Place them in `app/src/main/res/drawable` and update `games.json` to reference the new file names (without extension).  The `game_assets/` directory holds ZIP archives for each game; to add your own game module, create a ZIP containing a `launch.txt` or your runtime files and update the `game_asset_zip_url` field accordingly.

 - **Embedded game modules:** The `game_assets/` directory holds ZIP archives for each game. To add your own game module:
   1. **Create an asset folder** containing your game content. For HTML games include `index.html`, CSS and JavaScript files; for Lua games include your `.lua` scripts; for simple text‑based games include a `launch.txt`.
   2. **Compress the folder into a ZIP** and place it under `app/src/main/assets/game_assets` with a unique name.
  3. **Edit `games.json`:** point `game_asset_zip_url` to your ZIP and set the new `content_type` field to `html`, `lua` or `text`.  The runtime shell also inspects the extracted game folder at launch time: if it finds an `index.html` file it overrides the JSON value and loads the game via the embedded WebView; if it finds any `.lua` files it will eventually use a Lua interpreter (currently a placeholder); otherwise it defaults to `text` and displays `launch.txt`.

## 🎮 Gamepad navigation support

While the current implementation focuses on mouse/touch interaction, the UI layout has been kept simple and navigable to make it easier to integrate gamepad support later.  To add full D‑pad/joystick navigation, wrap interactive components with `Modifier.focusable()` and manage focus traversal using [`FocusRequester`](https://developer.android.com/reference/kotlin/androidx/compose/ui/focus/FocusRequester) and `onKeyEvent`.

## 📜 License

This project is provided under the **MIT License**.  You are free to use, modify and distribute it under the terms of that license.  Placeholder images included in this repository were generated using an AI and may be replaced without attribution; however, if you substitute them with assets from other authors, be sure to respect their respective licenses.