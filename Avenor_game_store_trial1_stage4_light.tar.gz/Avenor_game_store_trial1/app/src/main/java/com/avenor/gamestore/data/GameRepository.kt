package com.avenor.gamestore.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.BufferedReader

/**
 * Repository responsible for loading game data. Currently reads from a JSON asset bundled with the app.
 * Future versions can swap this implementation with a network backed API or database.
 */
import com.avenor.gamestore.models.Game

object GameRepository {
    private const val GAME_ASSET_FILE = "games.json"

    /**
     * Load the list of games from the bundled JSON file.
     *
     * This method blocks on file IO. In a real app you may want to call it from a coroutine or background thread.
     */
    fun loadGames(context: Context): List<Game> {
        return try {
            val jsonString = context.assets.open(GAME_ASSET_FILE).bufferedReader().use(BufferedReader::readText)
            Json { ignoreUnknownKeys = true }.decodeFromString(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}