package com.avenor.gamestore.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Data classes representing API responses and requests for library,
 * reviews, developers and version history.  These models mirror
 * corresponding Pydantic schemas defined in the backend.
 */

@Serializable
data class LibraryGame(
    @SerialName("game_id") val gameId: Int,
    val title: String,
    val description: String,
    val genre: String,
    val developer: String,
    @SerialName("version_installed") val versionInstalled: String? = null,
    @SerialName("latest_version") val latestVersion: String? = null
)

@Serializable
data class GameReview(
    @SerialName("user_id") val userId: Int,
    val rating: Int,
    @SerialName("review_text") val reviewText: String? = null,
    @SerialName("created_at") val createdAt: String
)

@Serializable
data class ReviewSummary(
    @SerialName("game_id") val gameId: Int,
    @SerialName("average_rating") val averageRating: Float,
    @SerialName("review_count") val reviewCount: Int
)

@Serializable
data class ReviewRequest(
    @SerialName("game_id") val gameId: Int,
    val rating: Int,
    @SerialName("review_text") val reviewText: String? = null
)

@Serializable
data class DeveloperGame(
    val id: Int,
    val title: String,
    val version: String,
    @SerialName("content_type") val contentType: String
)

@Serializable
data class DeveloperProfile(
    val id: Int,
    val name: String,
    val bio: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    val games: List<DeveloperGame> = emptyList()
)

@Serializable
data class GameVersionInfo(
    val id: Int,
    val version: String,
    val changelog: String? = null,
    @SerialName("patch_url") val patchUrl: String? = null,
    @SerialName("created_at") val createdAt: String
)