package com.avenor.gamestore.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.avenor.gamestore.ui.screens.CartScreen
import com.avenor.gamestore.ui.screens.GameDetailScreen
import com.avenor.gamestore.ui.screens.HomeScreen
import com.avenor.gamestore.ui.screens.InstallManagerScreen
import com.avenor.gamestore.ui.screens.LoginScreen

/**
 * Define the routes for navigation in the app.
 */
sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Home : Screen("home")
    object Detail : Screen("detail/{gameId}") {
        const val ARG_GAME_ID = "gameId"
        fun createRoute(gameId: Int) = "detail/$gameId"
    }
    object Cart : Screen("cart")
    object InstallManager : Screen("installManager")

    /**
     * Route for the profile settings screen, where users can switch or create
     * profiles.  No arguments are required.
     */
    object Profiles : Screen("profiles")

    /**
     * Route to the gameplay screen for a specific game. The game is identified by its
     * integer ID which matches the ID in the catalogue JSON. When navigating to this
     * route, the app should load the game assets from internal storage and display
     * the contained runtime.
     */
    object Gameplay : Screen("play/{gameId}") {
        const val ARG_GAME_ID = "gameId"
        fun createRoute(gameId: Int) = "play/$gameId"
    }

    /**
     * Route to a developer profile screen.  Accepts an integer developer ID
     * corresponding to the DeveloperProfile model on the backend.
     */
    object DeveloperProfile : Screen("developer/{developerId}") {
        const val ARG_DEVELOPER_ID = "developerId"
        fun createRoute(developerId: Int) = "developer/$developerId"
    }
}

@Composable
fun AppNavHost(startDestination: String = Screen.Login.route) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Login.route) {
            LoginScreen(onContinue = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Login.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onGameSelected = { id -> navController.navigate(Screen.Detail.createRoute(id)) },
                onCartClick = { navController.navigate(Screen.Cart.route) },
                onInstallManagerClick = { navController.navigate(Screen.InstallManager.route) },
                onSettingsClick = { navController.navigate(Screen.Profiles.route) }
            )
        }
        composable(
            Screen.Detail.route,
            arguments = listOf(navArgument(Screen.Detail.ARG_GAME_ID) { type = NavType.IntType })
        ) { backStackEntry ->
            val gameId = backStackEntry.arguments?.getInt(Screen.Detail.ARG_GAME_ID) ?: 0
            GameDetailScreen(
                gameId = gameId,
                onBack = { navController.popBackStack() },
                onPlayGame = { id -> navController.navigate(Screen.Gameplay.createRoute(id)) },
                onShowDownloads = { navController.navigate(Screen.InstallManager.route) },
                onDeveloperSelected = { devId -> navController.navigate(Screen.DeveloperProfile.createRoute(devId)) }
            )
        }
        composable(Screen.Cart.route) {
            CartScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.InstallManager.route) {
            InstallManagerScreen(onBack = { navController.popBackStack() })
        }

        // Profile settings screen
        composable(Screen.Profiles.route) {
            com.avenor.gamestore.ui.screens.ProfileSettingsScreen(navController = navController)
        }

        // Gameplay screen composable. Loads and displays contained runtime for the game.
        composable(
            Screen.Gameplay.route,
            arguments = listOf(navArgument(Screen.Gameplay.ARG_GAME_ID) { type = NavType.IntType })
        ) { backStackEntry ->
            val gameId = backStackEntry.arguments?.getInt(Screen.Gameplay.ARG_GAME_ID) ?: 0
            com.avenor.gamestore.ui.screens.GamePlayScreen(
                gameId = gameId,
                onBack = { navController.popBackStack() }
            )
        }

        // Developer profile screen
        composable(
            Screen.DeveloperProfile.route,
            arguments = listOf(navArgument(Screen.DeveloperProfile.ARG_DEVELOPER_ID) { type = NavType.IntType })
        ) { backStackEntry ->
            val devId = backStackEntry.arguments?.getInt(Screen.DeveloperProfile.ARG_DEVELOPER_ID) ?: 0
            com.avenor.gamestore.ui.screens.DeveloperProfileScreen(
                developerId = devId,
                onBack = { navController.popBackStack() },
                onGameSelected = { id -> navController.navigate(Screen.Detail.createRoute(id)) }
            )
        }
    }
}