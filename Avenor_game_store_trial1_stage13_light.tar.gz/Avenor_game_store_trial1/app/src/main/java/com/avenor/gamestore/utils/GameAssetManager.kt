package com.avenor.gamestore.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import com.avenor.gamestore.models.Game

/**
 * Utility class responsible for installing and checking game assets.
 *
 * Each game ships with a ZIP archive stored in the application's assets folder
 * (under `game_assets/`). This manager extracts the archive into the app's
 * internal storage to make it accessible offline. Only basic ZIP archives are
 * supported (no encryption).
 */
object GameAssetManager {
    private const val GAMES_DIR = "games"

    /**
     * Determine if the given game has already been installed on disk.
     *
     * @return true if a directory exists for the game, false otherwise.
     */
    fun isGameInstalled(context: Context, game: Game): Boolean {
        val dir = File(context.filesDir, "$GAMES_DIR/${game.id}")
        return dir.exists() && dir.isDirectory
    }

    /**
     * Install (extract) the ZIP archive for the given game into internal storage
     * by reading from the app's bundled assets. This method should be used
     * for legacy/local games where the archive is packaged with the APK. See
     * [downloadAndInstallGame] for remote download behaviour.
     */
    suspend fun installGame(context: Context, game: Game) {
        withContext(Dispatchers.IO) {
            extractZipToGameDir(context, context.assets.open(game.gameAssetZipUrl), game.id)
        }
    }

    /**
     * Download the game archive from the provided URL and extract it into
     * internal storage. Progress updates can be delivered via the provided
     * callback which reports a value between 0f and 1f. If the game does not
     * specify a download URL this method falls back to [installGame].
     *
     * @param progressCallback Called on the main thread to report download
     *        progress. This may be invoked frequently; UI code should be
     *        lightweight.
     */
    suspend fun downloadAndInstallGame(
        context: Context,
        game: Game,
        progressCallback: (Float) -> Unit
    ) {
        if (game.downloadUrl.isNullOrEmpty()) {
            installGame(context, game)
            return
        }
        withContext(Dispatchers.IO) {
            // Create destination directory
            val destDir = File(context.filesDir, "$GAMES_DIR/${game.id}")
            if (!destDir.exists()) destDir.mkdirs()
            // Download to temp file
            val client = okhttp3.OkHttpClient()
            val request = okhttp3.Request.Builder().url(game.downloadUrl!!).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) throw java.io.IOException("Failed to download")
            val body = response.body ?: throw java.io.IOException("No response body")
            val contentLength = body.contentLength().takeIf { it > 0 } ?: -1
            val tempFile = File.createTempFile("game_${game.id}", ".zip", context.cacheDir)
            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(8 * 1024)
                    var downloaded = 0L
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (contentLength > 0) {
                            val progress = downloaded.toFloat() / contentLength.toFloat()
                            withContext(Dispatchers.Main) {
                                progressCallback(progress.coerceIn(0f, 1f))
                            }
                        }
                    }
                }
            }
            // Extract downloaded zip
            tempFile.inputStream().use { ins ->
                extractZipToGameDir(context, ins, game.id)
            }
            // Clean up temp file
            tempFile.delete()
        }
    }

    /**
     * Extract the given input stream (pointing to a ZIP archive) into the
     * specified game directory. This helper encapsulates the common zip
     * extraction logic used by both local and remote installation paths.
     */
    private fun extractZipToGameDir(context: Context, inputStream: InputStream, gameId: Int) {
        val destDir = File(context.filesDir, "$GAMES_DIR/$gameId")
        if (!destDir.exists()) destDir.mkdirs()
        ZipInputStream(inputStream).use { zipIn ->
            var entry: ZipEntry? = zipIn.nextEntry
            while (entry != null) {
                val filePath = File(destDir, entry.name)
                if (entry.isDirectory) {
                    filePath.mkdirs()
                } else {
                    filePath.parentFile?.mkdirs()
                    FileOutputStream(filePath).use { fos ->
                        val buffer = ByteArray(4096)
                        var len: Int
                        while (zipIn.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                    }
                }
                zipIn.closeEntry()
                entry = zipIn.nextEntry
            }
        }
    }
}