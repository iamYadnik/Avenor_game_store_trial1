package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
// We don't use rememberCoroutineScope or launch directly because
// the LuaRuntimeManager manages its own coroutine scope internally.
import androidx.compose.ui.unit.dp
import java.io.File
import com.avenor.gamestore.utils.LuaRuntimeManager
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import android.graphics.Paint

/**
 * A simple placeholder screen for Lua‑based games.  Lists any `.lua` files
 * extracted in the game folder and informs the user that a Lua interpreter
 * will be integrated in a future release.  A back button returns the user
 * to the store.  When real Lua support is added, this screen can be
 * replaced with a proper runtime that loads and executes the selected
 * scripts.
 *
 * @param gameId Identifier of the game whose folder should be scanned for
 *               Lua scripts.
 * @param onBack Callback invoked when the user taps the back button.
 */
@Composable
fun LuaGameScreen(gameId: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    // Enumerate .lua files in the extracted game directory. We store the absolute
    // path along with the file name for running the script later.
    val luaFiles = remember(gameId) {
        val dir = File(context.filesDir, "games/$gameId")
        dir.listFiles()?.filter { it.extension.equals("lua", ignoreCase = true) }
            ?.map { it to it.name } ?: emptyList()
    }
    // Create a LuaRuntimeManager for this game ID
    val runtime = remember(gameId) { LuaRuntimeManager(context, gameId) }
    val logsState by runtime.logs.collectAsState()
    // State to toggle gamepad overlay
    val showGamepadOverlay = remember { mutableStateOf(false) }
    // Observe draw operations from the runtime. Whenever the Lua script
    // calls draw_api.render(), this state will update and cause the
    // Canvas below to recompose.
    val drawOps by runtime.drawOps.collectAsState()
    // Lazy list state for auto‑scrolling logs
    val listState = rememberLazyListState()

    // Auto‑scroll to the bottom whenever new log lines are added
    LaunchedEffect(logsState.size) {
        if (logsState.isNotEmpty()) {
            listState.animateScrollToItem(logsState.size - 1)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            // Header
            Text(
                text = "Lua Game",
                style = MaterialTheme.typography.headlineMedium
            )
            // Toggle overlay button
            Button(
                onClick = { showGamepadOverlay.value = !showGamepadOverlay.value },
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(text = if (showGamepadOverlay.value) "Hide Gamepad" else "Show Gamepad")
            }
            // List of available Lua scripts with run buttons
            if (luaFiles.isEmpty()) {
                Text(
                    text = "No Lua files detected.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                Text(
                    text = "Select a script to run:",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
                LazyColumn(
                    modifier = Modifier
                        .padding(top = 4.dp)
                ) {
                    items(luaFiles) { (file, name) ->
                        // Each row: file name and a Run button
                        Column(
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(text = name, style = MaterialTheme.typography.bodySmall)
                            Button(
                                onClick = {
                                    // Run the selected Lua script
                                    runtime.runScript(file.absolutePath)
                                },
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Text(text = "Run Script")
                            }
                        }
                    }
                }
            }

            // Output log area
            Text(
                text = "Output:",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp)
            )
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 4.dp),
                state = listState
            ) {
                items(logsState) { line ->
                    // Highlight errors (lines containing "error") in the error color
                    val isError = line.contains("error", ignoreCase = true)
                    val color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground
                    Text(text = line, style = MaterialTheme.typography.bodySmall, color = color)
                }
            }

            // Graphics canvas. Draws the operations pushed from Lua via draw_api.
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(top = 8.dp)
            ) {
                // Fill background with black for contrast
                drawRect(color = Color.Black, size = size)
                for (op in drawOps) {
                    when (op) {
                        is LuaRuntimeManager.DrawOperation.Rect -> {
                            drawRect(
                                color = Color(op.color),
                                topLeft = Offset(op.x, op.y),
                                size = Size(op.width, op.height)
                            )
                        }
                        is LuaRuntimeManager.DrawOperation.Text -> {
                            // Draw text using Android Canvas because Compose
                            // doesn't provide direct text drawing in drawScope.
                            drawContext.canvas.nativeCanvas.apply {
                                val paint = Paint().apply {
                                    isAntiAlias = true
                                    color = op.color
                                    textSize = op.size
                                }
                                drawText(op.text, op.x, op.y, paint)
                            }
                        }
                    }
                }
            }

            // Footer with actions
            Column(
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Button(
                    onClick = { runtime.clearLogs() },
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Text(text = "Clear Output")
                }
                Button(
                    onClick = onBack,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Text(text = "Back to Store")
                }
            }
        }
        // Gamepad overlay
        if (showGamepadOverlay.value) {
            // Build a map of key->boolean for overlay display.  We store it in a state so
            // that Compose recomposes when the values change.  Polling happens in
            // a LaunchedEffect below.
            val gamepadMapState = remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
            // Update the map whenever the overlay is visible or when new logs are appended
            LaunchedEffect(showGamepadOverlay.value, logsState.size) {
                val map = runtimeGetGamepadMap(runtime)
                gamepadMapState.value = map
            }
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
                    .padding(8.dp)
            ) {
                Text("Gamepad State", style = MaterialTheme.typography.bodyMedium)
                gamepadMapState.value.forEach { (k, v) ->
                    Text(text = "$k: ${'$'}v", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/**
 * Helper function used by the LuaGameScreen overlay to query the current
 * gamepad state from a [LuaRuntimeManager].  It returns a map of button
 * names to booleans.  This uses the private API of LuaRuntimeManager via
 * reflection to call getGamepadStateLua() and convert it to a Kotlin map.
 */
@Composable
private fun runtimeGetGamepadMap(runtime: LuaRuntimeManager): Map<String, Boolean> {
    return try {
        val method = runtime.javaClass.getDeclaredMethod("getGamepadStateLua")
        method.isAccessible = true
        val luaValue = method.invoke(runtime) as org.luaj.vm2.LuaValue
        val keys = listOf("up", "down", "left", "right", "a", "b", "x", "y", "start", "select")
        keys.associateWith { key -> luaValue.get(key).toboolean() }
    } catch (e: Exception) {
        emptyMap()
    }
}