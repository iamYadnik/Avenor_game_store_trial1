# Avenor Game Store Trial 1

This project is an open‑source Android application that serves as a lightweight game store, reminiscent of platforms like **Steam Deck** or the **Nintendo eShop**.  It is designed for indie and single‑player titles rather than ad‑based casual games.  The goal of this MVP is to demonstrate a console‑style browsing experience using modern Android technologies and to provide a clean foundation for future features such as downloads, cloud saves and subscriptions.

## ✨ Features

This second milestone builds upon the initial skeleton UI and introduces a **game catalogue with a contained runtime**.  Major capabilities include:

- **Console‑style UI** built with [Jetpack Compose](https://developer.android.com/jetpack/compose), optimised for full‑screen/gamepad navigation.  Navigate with touch, mouse or (in the future) D‑pad/joystick.
- **Login screen** with a “continue as guest” option (authentication hooks prepared for later).
- **Home screen** displaying a list of six demo games parsed from a local JSON asset (`games.json`).  Each item shows a title, short description and thumbnail.
- **Game detail page** that presents the full description, developer and genre of a selected title.  From here users can:
  * **Try Demo** – a lightweight button that opens a stub gameplay screen (no download required).
- **Install / Play Now** – downloads and extracts a ZIP archive from the app’s assets into internal storage using the built‑in `GameAssetManager`.  Once installed, the button changes to “Play Now” and launches the contained runtime.
- **Game Runtime Shell** – `GamePlayScreen` automatically inspects the installed game directory to decide how to run the content.  If an `index.html` file is present the runtime spins up an embedded WebView to render the game (including a fullscreen toggle and a simple in‑game menu).  If any `.lua` scripts are found a placeholder is displayed until a Lua interpreter is integrated.  Otherwise it falls back to the `content_type` declared in `games.json` and reads a `launch.txt` file as a plain text game.
* **Save/Load system for HTML games** – HTML5 games can persist their progress using a built‑in JavaScript bridge.  A `SaveManager` writes save files to `files/saves/{profileId}/{gameId}.json` in the app’s sandbox.  The WebView exposes two methods on `window.android`: `saveGameState(data: String)` and `loadGameState(): String`.  Games call these functions to save and restore JSON‑encoded state.  The example HTML demo demonstrates a simple score counter with Save/Load buttons.  When save data exists the store shows a **Resume Game** option instead of **Play Now**, and users can clear their save from the detail page.

* **Multiple local profiles and offline‑first cloud sync** – A new **Profile Settings** screen (accessed via the gear icon in the home toolbar) allows players to create and switch between profiles.  Each profile has a UUID and a user‑defined name stored in a `profiles.json` file in the app’s private storage, and the active profile determines the namespace for save data.  The MVP also introduces a `CloudSyncManager` that simulates backing up and restoring saves by zipping the entire `saves/{profileId}` directory into `files/cloud_saves/{profileId}.zip`.  From a game’s detail page users can manually trigger **Sync Save to Cloud** or **Restore Save from Cloud**; these operations run on a background thread and display a confirmation toast when finished.  This offline‑first design can later be replaced with a real backend (REST, Firebase or Git) and extended to support automatic sync and encryption.

* **Encrypted save storage** – For added security, all game saves are now encrypted on disk.  When a profile is created the app generates a unique 256‑bit AES key (encoded in Base64 and stored privately).  `SaveManager` uses this key to encrypt the JSON game state before writing it to `files/saves/{profileId}/{gameId}.json`.  The file contents consist of a Base64‑encoded IV and ciphertext separated by a colon; `loadGameState` automatically decrypts the data on read and falls back to plain text for backward compatibility.  Cloud backups are also encrypted: `CloudSyncManager` zips the entire save directory, encrypts the ZIP bytes with the same per‑profile key, and writes the result to `files/cloud_saves/{profileId}.zip`.  On restore the file is decrypted and extracted.  This placeholder encryption simulates password‑protected cloud saves and paves the way for secure server‑side storage.

* **Lua runtime engine** – A lightweight Lua interpreter powered by [LuaJ](https://github.com/luaj/luaj) is embedded in the app.  Games tagged with `"lua"` or containing `.lua` files launch a dedicated **Lua Game Screen**.  This screen enumerates all Lua scripts in the game folder and lets you run them with a single tap.  Script output appears in a scrollable, auto‑scrolling log with error highlighting, and there is an optional overlay that displays live gamepad state for debugging.  The interpreter now exposes a richer Android API:
  * `print(...)` – Writes text to the on‑screen log instead of standard out.
  * `save_state(key, value)` – Persists a string under the current profile’s save file.
  * `load_state(key)` – Retrieves the saved value associated with the key.
  * `get_profile_id()` – Returns the active profile’s ID.
  * `get_gamepad_state()` – Returns a table containing boolean values for `up`, `down`, `left`, `right`, `a`, `b`, `x`, `y`, `start` and `select`.  If no controller is connected all keys are `false` and a warning is logged.
  * `load_asset(filename)` – Reads a file from the game’s extracted asset folder and returns its contents encoded as Base64.  Use this to load JSON data, dialogue text or binary resources from Lua.
  * `draw_api.draw_rect(x, y, width, height, color)` – Queues a rectangle for the next frame.  Coordinates and dimensions are in pixels; colours are specified using hex strings like `"#FFCC00"` (RGB) or `"#AARRGGBB"` (ARGB).
  * `draw_api.draw_text(x, y, string, size, color)` – Queues a text primitive at a specified position with a font size (in pixels) and colour.  Text drawing uses the native Android canvas for crisp rendering.
  * `draw_api.clear_screen()` – Clears all previously rendered primitives as well as any queued ones.  Call this at the start of each frame.
  * `draw_api.render()` – Commits queued primitives to the on‑screen canvas.  Until `render()` is called, nothing will be drawn.  Use this at the end of your frame loop.
  The **Lua Demo** game (ID 7) demonstrates basic saving/loading of a counter, the **Lua Input Demo** (ID 8) showcases gamepad polling and asset loading by printing which buttons are pressed and reading a `dialogue.txt` file, and the new **Lua Graphics Demo** (ID 9) illustrates simple 2D graphics by animating a moving square and displaying a frame counter.  Together these examples mark the first playable Lua experiences inside the store and lay the groundwork for more sophisticated Lua‑based games.
- **Cart and download manager screens** remain placeholders but are still accessible from the app bar.
- **Modular architecture** separating data, UI, navigation and utility layers to simplify extension.

## 🛠️ Tech stack

- **Language:** Kotlin
- **UI Framework:** Jetpack Compose + Material 3
- **Navigation:** [AndroidX Navigation Compose](https://developer.android.com/jetpack/compose/navigation)
- **Serialization:** [Kotlinx Serialization](https://github.com/Kotlin/kotlinx.serialization) for loading games from a JSON asset
- **Minimum SDK:** 26 (Android 8.0)

## 📁 Project structure

The repo is organised as a typical Android project with an app module.  Key directories and files include:

```
Avenor_game_store_trial1/
├── build.gradle               # Project‑level Gradle script
├── settings.gradle            # Includes the :app module
├── app/
│   ├── build.gradle           # App module configuration, Compose enabled
│   ├── proguard-rules.pro     # ProGuard rules (empty for MVP)
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── assets/
│   │   │   ├── games.json         # Demo catalogue listing six games
│   │   │   └── game_assets/        # ZIP archives containing dummy game modules
│   │   │       ├── game1.zip
│   │   │       ├── …
│   │   │       └── game6.zip
│   │   ├── java/com/avenor/gamestore/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   └── GameRepository.kt (loads JSON)
│   │   │   ├── models/
│   │   │   │   └── Game.kt         # Data class for games
│   │   │   │   └── GameContentType.kt # Enum for classifying content types
│   │   │   ├── utils/
│   │   │   │   └── GameAssetManager.kt (handles ZIP extraction)
│   │   │   │   └── ProfileManager.kt (creates and manages local user profiles)
│   │   │   │   └── CloudSyncManager.kt (simulates cloud backup/restore for saves)
│   │   │   ├── ui/
│   │   │   │   ├── navigation/Navigation.kt (defines routes)
│   │   │   │   ├── screens/
│   │   │   │   │   ├── HomeScreen.kt         # Lists all games
│   │   │   │   │   ├── GameDetailScreen.kt   # Shows detailed info, install/play buttons
│   │   │   │   │   ├── GamePlayScreen.kt     # Displays the contained runtime
│   │   │   │   │   ├── LoginScreen.kt
│   │   │   │   │   ├── CartScreen.kt         # Placeholder
│   │   │   │   │   ├── InstallManagerScreen.kt # Placeholder
│   │   │   │   │   └── ProfileSettingsScreen.kt # UI to view/add/switch profiles
│   │   │   │   └── theme/Theme.kt
│   │   └── res/drawable/
│   │       ├── game1.png
│   │       ├── game2.png
│   │       ├── …
│   │       └── game6.png       # Placeholder thumbnails
│   └── …
└── README.md
```

## 🚀 Building and running

This project is entirely offline‑compatible.  You can open it directly in **Android Studio (Hedgehog or later)** and run it on a device or emulator without any network access.

1. **Clone or extract** the repository into your local development workspace.
2. **Open** the project with Android Studio.
3. When prompted, **let Android Studio download the required Gradle wrappers** (internet is not required for local builds if your environment already has the Android Gradle plugin).
4. **Build and run** the `app` module on an emulator or physical device.

> **Note:** The Gradle scripts specify a Compose version (`compose_ui_version`) and Kotlin version in the top‑level `build.gradle`.  Update these values to the latest stable releases if you encounter compilation issues.

After installation, the game ZIP archives are unpacked into your app’s internal storage.  You can find the extracted folders under `data/data/<package>/files/games/{id}` on your device.  To try another game you simply tap “Install” or “Play Now” from the detail page – no external APKs are installed.

## 🧩 Extending the MVP

The current milestone lays the groundwork for a robust digital storefront.  The following ideas show how you can expand this project:

- **Backend/API integration:** Swap out `GameRepository` for a network‑backed implementation (Firebase, REST or GraphQL) to fetch game listings, prices and entitlements.  The Compose UI already reacts to lists of `Game` objects.
- **Download manager:** The `InstallManagerScreen` still shows a dummy message.  You could surface real download tasks here, track progress, allow pausing/canceling and verify checksums.  Integration with Android’s DownloadManager or WorkManager would make downloads robust.
- **Rich runtime support:** Instead of reading a `launch.txt` file, embed a Unity or Godot runtime in your app (as a library) and load game assets from the installed folder.  For HTML5/WebAssembly games, an embedded WebView can host the content.
- **Cloud saves, subscriptions, trials:** Build screens and logic to handle user entitlements.  Cloud save APIs, trial periods and subscription management can be layered on top of the existing architecture.
- **Improved assets:** The `res/drawable` folder contains six pixel‑art thumbnails generated for demonstration.  To use real game covers, download PNG files from sources like [OpenGameArt.org](https://opengameart.org/), [Itch.io](https://itch.io/) or [Kenney.nl](https://www.kenney.nl/assets).  Place them in `app/src/main/res/drawable` and update `games.json` to reference the new file names (without extension).  The `game_assets/` directory holds ZIP archives for each game; to add your own game module, create a ZIP containing a `launch.txt` or your runtime files and update the `game_asset_zip_url` field accordingly.

 - **Embedded game modules:** The `game_assets/` directory holds ZIP archives for each game. To add your own game module:
   1. **Create an asset folder** containing your game content. For HTML games include `index.html`, CSS and JavaScript files; for Lua games include your `.lua` scripts; for simple text‑based games include a `launch.txt`.
   2. **Compress the folder into a ZIP** and place it under `app/src/main/assets/game_assets` with a unique name.
  3. **Edit `games.json`:** point `game_asset_zip_url` to your ZIP and set the new `content_type` field to `html`, `lua` or `text`.  The runtime shell also inspects the extracted game folder at launch time: if it finds an `index.html` file it overrides the JSON value and loads the game via the embedded WebView; if it finds any `.lua` files it will eventually use a Lua interpreter (currently a placeholder); otherwise it defaults to `text` and displays `launch.txt`.

   ### Saving game state in HTML modules

   HTML5 games can persist progress using a special JavaScript interface exposed by the WebView.  Your scripts may call:

   * `window.android.saveGameState(jsonString)` – Persists a string (preferably JSON) to a file under `files/saves/{profileId}/{gameId}.json`.  Replace `jsonString` with a serialized representation of your game state (e.g. `{ score: 42, level: 3 }`).
   * `window.android.loadGameState()` – Returns the previously saved string, or an empty string if none exists.  Use `JSON.parse()` to reconstruct your state before applying it.

   The example demo includes Save and Load buttons that call these methods.  When a save file exists, the store’s detail page will show a **Resume Game** button and provide a **Clear Save** option to delete the file.
   ### Managing local profiles and syncing saves

   Players can maintain separate progress on a single device by creating multiple profiles.  Tap the **gear icon** on the home screen to open the **Profile Settings** page.  From there you can:

   - View existing profiles along with their unique UUIDs.  The active profile is marked **Active**.
   - Switch to another profile by tapping **Switch**.  A snackbar will confirm the change, and the app will load save files under the new profile’s namespace.
   - Create a new profile by entering a name.  Profiles are stored as an array in `files/profiles/profiles.json` for example:

     ```json
     [
       { "id": "uuid-1", "name": "Player1" },
       { "id": "uuid-2", "name": "Sibling" }
     ]
     ```

   To protect progress against accidental deletion or device loss, you can manually back up and restore saves to a local **cloud** directory.  On a game’s detail page, additional buttons appear when a save file exists:

   - **Sync Save to Cloud** – Compresses all files under `files/saves/{profileId}` into `files/cloud_saves/{profileId}.zip`.  In a production app you would replace this with a request to your own server or cloud storage.
   - **Restore Save from Cloud** – Unpacks `files/cloud_saves/{profileId}.zip` back into `files/saves/{profileId}`, overwriting any existing saves.  A toast confirms completion.

   Because this is an offline‑first MVP the “cloud” is simply another folder within the app’s private storage; however, the architecture is structured such that you can swap the implementation of `CloudSyncManager` for API calls or Git operations in a later stage.  Automatic syncing, conflict resolution and encryption are beyond the scope of this milestone.

### Encrypted save storage

To protect player progress from prying eyes and accidental corruption, the app encrypts all game saves on disk.  When you create a new profile the app generates a random 32‑byte (256‑bit) AES key and stores it privately in SharedPreferences.  Any call to `window.android.saveGameState(...)` goes through the `SaveManager`, which encrypts the JSON string with this key using AES in CBC mode with PKCS#5 padding.  The encrypted data is stored as two Base64‑encoded components (`iv:ciphertext`) in `files/saves/{profileId}/{gameId}.json`.  Loading a game calls `loadGameState()`, which decrypts the contents transparently.  Old, unencrypted save files are still supported – if decryption fails, the raw contents are returned.

When performing a cloud backup, the entire save directory is zipped and then encrypted using the same per‑profile key before being written to `files/cloud_saves/{profileId}.zip`.  Restoring from the cloud decrypts the archive and extracts its contents.  This approach emulates password‑protected ZIP files and makes it easy to transition to a secure backend in the future.

### Lua runtime support

The game runtime now includes a basic Lua interpreter so that simple Lua games can run inside the store.  If a game’s `content_type` is set to `"lua"` in `games.json` or if the installer detects `.lua` files in the game’s asset folder, the app launches a **Lua Game Screen**.  This screen scans the game’s installation directory for `.lua` files and lists them along with a **Run Script** button.  When you tap **Run Script** the app loads the selected file into the embedded Lua interpreter and executes it on a background thread.  Printed output is collected in a scrollable log that auto‑scrolls to the newest line and highlights errors in red.  A gear‑style button toggles a live gamepad overlay showing the current state of each button.

The interpreter exposes several Android APIs to Lua scripts:

* `print(...)` – Sends text to the Compose log viewer.  Multiple arguments are separated by a tab.  Error messages (containing the word “error”) are highlighted.
* `save_state(key, value)` / `load_state(key)` – Persist and retrieve simple string values under the active profile’s encrypted save file.
* `get_profile_id()` – Returns the UUID of the active profile, allowing scripts to display or log user information.
* `get_gamepad_state()` – Returns a table containing boolean fields for the D‑pad (`up`, `down`, `left`, `right`), face buttons (`a`, `b`, `x`, `y`), and system buttons (`start`, `select`).  If no gamepad is connected the table contains all `false` values and a warning is appended to the log.
* `load_asset(filename)` – Reads a file from the game’s unzipped asset folder and returns its contents as a Base64‑encoded string, or `nil` if the file doesn’t exist.  You can use this to load maps, dialogue or other resources packaged with the game.
* `draw_api.draw_rect(x, y, width, height, color)` – Queues a rectangle to be drawn on the next frame.  Colours accept `#RRGGBB` or `#AARRGGBB` strings.
* `draw_api.draw_text(x, y, string, size, color)` – Queues text to be drawn at `(x, y)` with the given pixel size and colour.
* `draw_api.clear_screen()` – Clears all queued and previously rendered primitives.
* `draw_api.render()` – Commits the queued primitives to the on‑screen canvas.  Nothing appears until `render()` is called.

Two example Lua games are included:

* **Lua Demo** (`game7_lua_demo.zip`) prints a greeting, reads a counter from saved state, increments it and saves it back.  Each run updates the counter and prints the new value.
* **Lua Input Demo** (`game8_lua_input_demo.zip`) demonstrates polling the gamepad state and loading a text asset.  It prints which buttons are pressed and reads `dialogue.txt` from its ZIP via `load_asset()`.
* **Lua Graphics Demo** (`game9_lua_graphics_demo.zip`) demonstrates the new 2D drawing API.  It animates a coloured square moving across the screen, prints a frame counter and listens to left/right D‑pad input to change direction.

Use these examples as templates for developing your own Lua‑based mini‑games.  Future milestones will expand this runtime to include timers, simple 2D rendering via the Android Canvas/WebGL and support for more sophisticated engines like LÖVE or Godot.

## 🎮 Gamepad navigation support

While the current implementation focuses on mouse/touch interaction, the UI layout has been kept simple and navigable to make it easier to integrate gamepad support later.  To add full D‑pad/joystick navigation, wrap interactive components with `Modifier.focusable()` and manage focus traversal using [`FocusRequester`](https://developer.android.com/reference/kotlin/androidx/compose/ui/focus/FocusRequester) and `onKeyEvent`.

## 📜 License

This project is provided under the **MIT License**.  You are free to use, modify and distribute it under the terms of that license.  Placeholder images included in this repository were generated using an AI and may be replaced without attribution; however, if you substitute them with assets from other authors, be sure to respect their respective licenses.

## 🌐 Online store and downloads (Stage 10)

With Stage 10, the Avenor Game Store begins transitioning from a static, offline catalogue to a dynamic online marketplace backed by the new FastAPI server.  These changes affect both the data layer and the installation flow within the mobile app:

- **Network catalogue:** The `GameRepository` now attempts to fetch games from the backend via a `GET /games` call when the home screen loads.  If the server cannot be reached the app falls back to the bundled `games.json` ensuring offline functionality.  A retrofit‑based `GameApiService` and `NetworkModule` handle networking and JSON conversion.

- **Remote downloads:** Games may specify a `download_url` in the API response.  When present, the **Install** button triggers `GameAssetManager.downloadAndInstallGame()` which streams the ZIP over HTTP using OkHttp, updates a progress indicator in the UI, unpacks the archive into the app’s internal games directory and deletes the temporary file.  If no `download_url` is provided the manager falls back to extracting the archived asset shipped with the APK.

- **JWT authentication:** All network requests include an `Authorization: Bearer <token>` header injected by an OkHttp interceptor.  A minimal `UserManager` stores and retrieves the token from shared preferences.  In future releases the login screen will authenticate against the backend to obtain a real JWT.

These enhancements lay the groundwork for a fully online game store.  The mobile client can now display live content and install games from a remote server while preserving offline capability through graceful fallbacks.