package com.avenor.gamestore.models

/**
 * Describes the type of content contained within a game's asset package. This
 * allows the runtime shell to decide how to render or execute the game. When
 * new content types are added (e.g. Godot, Unity, Lua/SDL), extend this enum
 * accordingly.
 */
enum class GameContentType(val key: String) {
    /** HTML5/JavaScript game, loaded via a WebView. */
    HTML("html"),
    /** Lua scripts (placeholder for future interpreter integration). */
    LUA("lua"),
    /** Plain text file (fallback) displayed via Compose Text. */
    TEXT("text");

    companion object {
        /**
         * Convert a raw string into a [GameContentType], defaulting to [TEXT]
         * for unknown values.
         */
        fun fromKey(key: String?): GameContentType {
            return values().firstOrNull { it.key.equals(key, ignoreCase = true) } ?: TEXT
        }
    }
}