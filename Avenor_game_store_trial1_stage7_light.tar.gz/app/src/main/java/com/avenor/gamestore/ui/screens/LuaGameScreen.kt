package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

/**
 * A simple placeholder screen for Lua‑based games.  Lists any `.lua` files
 * extracted in the game folder and informs the user that a Lua interpreter
 * will be integrated in a future release.  A back button returns the user
 * to the store.  When real Lua support is added, this screen can be
 * replaced with a proper runtime that loads and executes the selected
 * scripts.
 *
 * @param gameId Identifier of the game whose folder should be scanned for
 *               Lua scripts.
 * @param onBack Callback invoked when the user taps the back button.
 */
@Composable
fun LuaGameScreen(gameId: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    // Enumerate .lua files in the extracted game directory
    val luaFiles = remember(gameId) {
        val dir = File(context.filesDir, "games/$gameId")
        dir.listFiles()?.filter { it.extension.equals("lua", ignoreCase = true) }?.map { it.name } ?: emptyList()
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Lua Interpreter Coming Soon",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = "The following Lua scripts were found in this game:",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (luaFiles.isEmpty()) {
            Text(
                text = "No Lua files detected.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.padding(top = 8.dp)
            ) {
                items(luaFiles) { fileName ->
                    Text(text = fileName, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text(
            text = "Lua support is not available yet. A future update will allow these scripts to run.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 12.dp)
        )
        Button(
            onClick = onBack,
            modifier = Modifier.padding(top = 24.dp)
        ) {
            Text(text = "Back to Store")
        }
    }
}