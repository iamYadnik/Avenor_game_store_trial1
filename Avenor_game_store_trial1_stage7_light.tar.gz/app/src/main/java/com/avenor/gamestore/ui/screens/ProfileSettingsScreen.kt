package com.avenor.gamestore.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.avenor.gamestore.utils.ProfileManager
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

/**
 * Screen that allows users to view existing profiles, switch between them
 * and create new profiles.  The active profile is highlighted and
 * switching provides feedback via a snackbar.  New profiles prompt for
 * a name using an AlertDialog.
 *
 * @param navController Navigation controller to handle back navigation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var profiles by remember { mutableStateOf<List<ProfileManager.Profile>>(emptyList()) }
    var activeProfileId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }

    // Provide a coroutine scope for snackbar operations
    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()

    // Load profiles and active id on first composition
    LaunchedEffect(Unit) {
        // Ensure at least one profile exists
        ProfileManager.getOrCreateDefaultProfile(context)
        profiles = ProfileManager.getProfiles(context)
        activeProfileId = ProfileManager.getActiveProfileId(context)
    }

    fun refresh() {
        profiles = ProfileManager.getProfiles(context)
        activeProfileId = ProfileManager.getActiveProfileId(context)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Profiles", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(profiles) { profile ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = profile.name,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = profile.id,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1
                            )
                        }
                        if (profile.id == activeProfileId) {
                            Text(
                                text = "Active",
                                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        } else {
                            Button(onClick = {
                                ProfileManager.setActiveProfileId(context, profile.id)
                                refresh()
                                // Show a confirmation snackbar
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Switched to ${profile.name}")
                                }
                            }) {
                                Text(text = "Switch")
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.size(16.dp))
            Button(
                onClick = { showCreateDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(text = "Create New Profile")
            }
            Spacer(modifier = Modifier.size(16.dp))
        }

        // Dialog to create a new profile
        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text(text = "New Profile") },
                text = {
                    Column {
                        Text(text = "Enter a name for your new profile:")
                        androidx.compose.material3.OutlinedTextField(
                            value = newProfileName,
                            onValueChange = { newProfileName = it },
                            label = { Text(text = "Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (newProfileName.isNotBlank()) {
                            ProfileManager.addProfile(context, newProfileName.trim())
                            refresh()
                            newProfileName = ""
                            showCreateDialog = false
                        }
                    }) {
                        Text("Create")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showCreateDialog = false
                        newProfileName = ""
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}